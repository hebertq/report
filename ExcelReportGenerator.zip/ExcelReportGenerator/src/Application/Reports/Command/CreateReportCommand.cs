﻿using MediatR;

namespace ExcelReportGenerator.Application.Reports.Command
{
    public class CreateReportCommand : IRequest<string>
    {
    }
}
