﻿using AutoMapper;
using ExcelReportGenerator.Application.Common.Interfaces;
using ExcelReportGenerator.Application.Reports.Command;
using ExcelReportGenerator.Domain.Entities.Todos;
using MediatR;

namespace ExcelReportGenerator.Application.Reports.Handlers.v1
{
    public class CreateReportCommandHandler:IRequestHandler<CreateReportCommand, string>
    {
        private readonly ITodoService _todoService;
        private readonly IMapper _mapper;

        public CreateReportCommandHandler(ITodoService todoService, IMapper mapper)
        {
            _todoService = todoService;
            _mapper = mapper;
        }

        public async Task<string> Handle(CreateReportCommand request, CancellationToken cancellationToken)
        {
            var response = await _todoService.CreateTodo(_mapper.Map<TodoEntity>(request));

            return "";
        }
    }
}
