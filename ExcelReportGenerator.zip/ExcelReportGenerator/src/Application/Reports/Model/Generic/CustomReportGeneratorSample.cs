﻿using Domain.Reports;

namespace ExcelReportGenerator.Application.Reports.Model.Generic
{
    public class CustomReportGeneratorSample : ReportBase
    {
        public override string ReportName => "Custom report generator sample";

        public override string Title => throw new NotImplementedException();

        public override string SubTitle => throw new NotImplementedException();

        public override string Company => throw new NotImplementedException();
    }
}
