﻿using ExcelReportGenerator.Application.Common.Interfaces;
using ExcelReportGenerator.Application.Common.Models;
using ExcelReportGenerator.Domain.Entities.Nomina.v1;

namespace ExcelReportGenerator.Application.Reports.Model.Nomina
{
    public class NominaQuincenal : ReportBaseEvent<List<Employee>>, IRportModel
    {
        public override string ReportName => "Reporte de nomina";

        public override string Title => $"Nomina Operativa {Company}";

        public override string SubTitle => "Del 01-01-202525 al 15-01-2025";

        public override string Company => throw new NotImplementedException();

        public NominaQuincenal()
        {
            setInitData();
        }

        public void setInitData()
        {
            Model = [];
        }

        private readonly IDictionary<string, Employee[]> _employeesByDepartmentCache = new Dictionary<string, Employee[]>();

        public IEnumerable<string> GetDepartments()
        {
            return GetEmployeesAsIEnumerable().Select(e => e.DepartmentName).Distinct();
        }

        public IEnumerable<Employee> GetDepartmentEmployees(string department)
        {
            if (_employeesByDepartmentCache.TryGetValue(department, out var result))
            {
                return result;
            }

            result = GetEmployeesAsIEnumerable().Where(e => e.DepartmentName == department).ToArray();
            _employeesByDepartmentCache[department] = result;
            return result;
        }


        public IEnumerable<Employee> GetEmployeesAsIEnumerable(string? department = null)
        {
            IList<Employee> result = new List<Employee>();
            if (department != null)
            {
                if (Model is null)
                    return result;

                result = Model.Where(x => x.DepartmentName.Equals(department)).ToList();
            }
            else
            {
                if (Model is null)
                    return result;

                result = Model;
            }

            return result;
        }
    }
}
