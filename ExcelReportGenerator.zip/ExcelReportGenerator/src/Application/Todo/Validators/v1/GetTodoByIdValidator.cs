﻿using FluentValidation;
using ExcelReportGenerator.Application.Todo.Queries.v1;

namespace ExcelReportGenerator.Application.Todo.Validators.v1
{
    public class GetTodoByIdValidator : AbstractValidator<GetTodoByIdQuery>
    {
        public GetTodoByIdValidator()
        {
            RuleFor(ct => ct.Id)
                .NotEmpty()
                .NotNull();
        }
    }
}
