﻿using AutoMapper;
using LAFISE.CrossCutting.Core.Exceptions;
using ExcelReportGenerator.Application.Common.Interfaces;
using ExcelReportGenerator.Application.Todo.Dto.v1;
using ExcelReportGenerator.Application.Todo.Queries.v1;
using MediatR;

namespace ExcelReportGenerator.Application.Todo.Handlers.v1
{
    public class GetTodoByIdQueryHandler : IRequestHandler<GetTodoByIdQuery, TodoDto>
    {
        private readonly ITodoService _todoService;
        private readonly IMapper _mapper;

        public GetTodoByIdQueryHandler(ITodoService todoService, IMapper mapper)
        {
            _todoService = todoService;
            _mapper = mapper;
        }

        public async Task<TodoDto> Handle(GetTodoByIdQuery request, CancellationToken cancellationToken)
        {
            var todo = await _todoService.GetTodoById(request.Id);

            if (todo is null)
                throw new NotFoundException($"The todo with id {request.Id} doesn't exist");

            return _mapper.Map<TodoDto>(todo);
        }
    }
}
