﻿using AutoMapper;
using ExcelReportGenerator.Application.Common.Interfaces;
using ExcelReportGenerator.Application.Todo.Dto.v1;
using ExcelReportGenerator.Application.Todo.Queries.v1;
using MediatR;

namespace ExcelReportGenerator.Application.Todo.Handlers.v1
{
    public class GetTodosQueryHandler : IRequestHandler<GetTodosQuery, List<TodoDto>>
    {
        private readonly ITodoService _todoService;
        private readonly IMapper _mapper;

        public GetTodosQueryHandler(ITodoService todoService, IMapper mapper)
        {
            _todoService = todoService;
            _mapper = mapper;
        }

        public async Task<List<TodoDto>> Handle(GetTodosQuery request, CancellationToken cancellationToken)
        {
            var todos = await _todoService.GetTodos();

            return _mapper.Map<List<TodoDto>>(todos);
        }
    }
}
