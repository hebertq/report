﻿using ExcelReportGenerator.Application.Common.Interfaces;

namespace ExcelReportGenerator.Application.Common.Helpers
{
    public static class DomainReportHelper
    {
        static IEnumerable<Type> _eventTypes = typeof(IRportModel).Assembly.GetTypes()
                .Where(t => !t.IsAbstract && t.IsPublic && typeof(IRportModel).IsAssignableFrom(t))
                .OrderBy(t => t.Name);
        public static IEnumerable<Type> GetDomainEventTypes()
        {
            return _eventTypes;
        }
    }
}
