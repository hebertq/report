﻿namespace ExcelReportGenerator.Application.Common.Interfaces
{
    public interface IRportModel
    {
        void setInitData();
    }
}
