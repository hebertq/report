﻿namespace ExcelReportGenerator.Application.Common.Interfaces
{
    public interface IReportService
    {
        Task<string?> RenderToPdfReport(Type reportType, string reportName);

        Task<string?> RenderToExcelReport(Type reportType, string reportName);
    }
}
