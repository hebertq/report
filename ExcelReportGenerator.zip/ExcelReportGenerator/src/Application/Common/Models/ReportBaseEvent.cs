﻿using Domain.Reports;

namespace ExcelReportGenerator.Application.Common.Models
{
    public abstract class ReportBaseEvent<TModel> : ReportBase where TModel : new()
    {
        public TModel Model { get; set; } = new TModel();
    }
}
