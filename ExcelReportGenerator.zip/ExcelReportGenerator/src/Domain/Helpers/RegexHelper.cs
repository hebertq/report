﻿using System.Text.RegularExpressions;

namespace Domain.Helpers;

public static class RegexHelper
{
    public static string SafeEscape(string value)
    {
        return value == null ? null : Regex.Escape(value);
    }
}