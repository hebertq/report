﻿namespace Domain.Helpers;

public static class ArgumentHelper
{
    public const string NullParamMessage = "Parameter cannot be null";

    public const string EmptyStringParamMessage = "Parameter cannot be null or empty";
}