﻿namespace Domain.Converters;

public interface IGenericConverter<in TIn, out TOut> : IConverter
{
    TOut Convert(TIn input);
}