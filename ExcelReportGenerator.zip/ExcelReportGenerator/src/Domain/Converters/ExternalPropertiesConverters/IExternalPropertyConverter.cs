﻿namespace Domain.Converters.ExternalPropertiesConverters;

public interface IExternalPropertyConverter<out TOut> : IGenericConverter<string, TOut>
{
}