﻿namespace Domain.Converters;

public interface IConverter
{
    object Convert(object input);
}