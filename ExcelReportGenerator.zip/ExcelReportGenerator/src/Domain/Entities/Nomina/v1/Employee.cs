﻿using Domain.Attributes;
using Domain.Enums;

namespace ExcelReportGenerator.Domain.Entities.Nomina.v1
{
    public class Employee
    {
        public string DepartmentName { get; set; }

        public string LastName { get; set; }

        public string FirstName { get; set; }

        [NullValue("N/A")]
        public string MiddleName { get; set; }

        [ExcelColumn(AdjustToContent = true)]
        public string JobTitle { get; set; }

        [ExcelColumn(Caption = "Gender")]
        public string Sex { get; set; }

        [ExcelColumn(AggregateFunction = AggregateFunction.Max)]
        public DateTime BirthDate { get; set; }

        [ExcelColumn(AggregateFunction = AggregateFunction.Min)]
        public DateTime HireDate { get; set; }

        [ExcelColumn(DisplayFormat = "$#,0.00")]
        public decimal Rate { get; set; }
    }
}
