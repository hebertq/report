﻿namespace Domain.Attributes;

/// <summary>
/// Marks panel property which can be populated from excel
/// </summary>
[AttributeUsage(AttributeTargets.Property)]
public class ExternalPropertyAttribute : Attribute
{
    public Type Converter { get; set; }
}