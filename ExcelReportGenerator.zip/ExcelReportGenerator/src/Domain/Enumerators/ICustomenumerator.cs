﻿using System.Collections;

namespace Domain.Enumerators;

public interface ICustomEnumerator : IEnumerator
{
    int RowCount { get; }
}