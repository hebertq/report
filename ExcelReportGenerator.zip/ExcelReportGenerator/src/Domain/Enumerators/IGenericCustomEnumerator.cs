﻿namespace Domain.Enumerators;

public interface IGenericCustomEnumerator<out T> : ICustomEnumerator, IEnumerator<T>
{
}