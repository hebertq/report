﻿namespace Domain.Reports
{
    public abstract class ReportBase
    {
        public abstract string ReportName { get; }

        public abstract string Title { get; }

        public abstract string SubTitle { get; }

        public abstract string Company { get; }

        public static string ReportTime => DateTime.Now.ToString("g");
    }
}
