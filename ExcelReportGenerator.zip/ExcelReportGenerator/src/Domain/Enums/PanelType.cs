﻿namespace Domain.Enums;

public enum PanelType
{
    Vertical,
    Horizontal,
}