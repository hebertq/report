﻿namespace Domain.Enums;

public enum Direction
{
    Bottom,
    Right,
    Top,
    Left,
}