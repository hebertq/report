﻿namespace Domain.Enums;

public enum ShiftType
{
    Cells,
    Row,
    NoShift,
}