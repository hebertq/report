﻿namespace Domain.Constants
{
    public static class Constants
    {
        public const string InvalidTemplateMessage = "Template \"{0}\" is invalid";
    }
}
