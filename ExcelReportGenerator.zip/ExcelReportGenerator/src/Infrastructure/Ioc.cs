﻿using SimpleInjector;

namespace Application;

public static class Ioc
{
    public static Container? Container { get; set; }
}