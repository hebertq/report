﻿namespace Infrastructure.Rendering.Providers.DataItemValueProviders;

internal interface IDataItemValueProviderFactory
{
    IDataItemValueProvider Create(object data);
}