﻿namespace Infrastructure.Rendering.Panels;

internal interface IDataItemPanel : IPanel
{
    HierarchicalDataItem DataItem { get; set; }
}