﻿using ClosedXML.Excel;
using Domain.Attributes;
using Domain.Converters;
using Domain.Helpers;
using Infrastructure.Rendering.TemplateProcessors;
using System.Reflection;

namespace Infrastructure.Rendering.Panels.ExcelPanels;

internal class ExcelPanelFactory
{
    private readonly object _report;
    private readonly ITemplateProcessor _templateProcessor;
    private readonly PanelParsingSettings _panelParsingSettings;

    private IXLNamedRange _namedRange;
    private IDictionary<string, string> _properties;

    public ExcelPanelFactory(object report, ITemplateProcessor templateProcessor, PanelParsingSettings panelParsingSettings)
    {
        _report = report ?? throw new ArgumentNullException(nameof(report), ArgumentHelper.NullParamMessage);
        _templateProcessor = templateProcessor ?? throw new ArgumentNullException(nameof(templateProcessor), ArgumentHelper.NullParamMessage);
        _panelParsingSettings = panelParsingSettings ?? throw new ArgumentNullException(nameof(panelParsingSettings), ArgumentHelper.NullParamMessage);
    }

    public IExcelPanel Create(IXLNamedRange namedRange, IDictionary<string, string> properties)
    {
        _namedRange = namedRange ?? throw new ArgumentNullException(nameof(namedRange), ArgumentHelper.NullParamMessage);
        _properties = properties ?? new Dictionary<string, string>(0);

        IExcelPanel panel;

        int prefixIndex = namedRange.Name.IndexOf(_panelParsingSettings.PanelPrefixSeparator, StringComparison.CurrentCultureIgnoreCase);
        if (prefixIndex == -1)
        {
            throw new InvalidOperationException($"Panel name \"{namedRange.Name}\" does not contain prefix separator \"{_panelParsingSettings.PanelPrefixSeparator}\"");
        }

        string prefix = namedRange.Name.Substring(0, prefixIndex);
        if (prefix.Equals(_panelParsingSettings.SimplePanelPrefix, StringComparison.CurrentCultureIgnoreCase))
        {
            panel = CreateSimplePanel();
        }
        else if (prefix.Equals(_panelParsingSettings.DataSourcePanelPrefix, StringComparison.CurrentCultureIgnoreCase))
        {
            panel = CreateDataSourcePanel();
        }
        else if (prefix.Equals(_panelParsingSettings.DynamicDataSourcePanelPrefix, StringComparison.CurrentCultureIgnoreCase))
        {
            panel = CreateDynamicPanel();
        }
        else if (prefix.Equals(_panelParsingSettings.TotalsPanelPrefix, StringComparison.CurrentCultureIgnoreCase))
        {
            panel = CreateTotalsPanel();
        }
        else
        {
            throw new NotSupportedException($"Panel type with prefix \"{prefix}\" is not supported");
        }

        FillPanelProperties(panel);
        return panel;
    }

    private IExcelPanel CreateSimplePanel()
    {
        return new ExcelPanel(_namedRange.Ranges.First(), _report, _templateProcessor);
    }

    private IExcelPanel CreateDataSourcePanel()
    {
        return new ExcelDataSourcePanel(GetDataSourceProperty("Data source panel must have the property \"DataSource\""), _namedRange, _report, _templateProcessor);
    }

    private IExcelPanel CreateDynamicPanel()
    {
        return new ExcelDataSourceDynamicPanel(GetDataSourceProperty("Dynamic data source panel must have the property \"DataSource\""), _namedRange, _report, _templateProcessor);
    }

    private IExcelPanel CreateTotalsPanel()
    {
        return new ExcelTotalsPanel(GetDataSourceProperty("Totals panel must have the property \"DataSource\""), _namedRange, _report, _templateProcessor);
    }

    private string GetDataSourceProperty(string errorMessage)
    {
        if (_properties.TryGetValue("DataSource", out string dataSource))
        {
            return dataSource;
        }
        throw new InvalidOperationException(errorMessage);
    }

    private void FillPanelProperties(IExcelPanel panel)
    {
        if (!_properties.Any())
        {
            return;
        }

        PropertyInfo[] externalProperties = panel.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public)
            .Where(p => p.IsDefined(typeof(ExternalPropertyAttribute), true)).ToArray();
        foreach (KeyValuePair<string, string> prop in _properties)
        {
            PropertyInfo externalProp = externalProperties.SingleOrDefault(p => p.Name == prop.Key);
            if (externalProp != null)
            {
                var externalPropAttr = Domain.Extensions.CustomAttributeExtensions.GetCustomAttribute<ExternalPropertyAttribute>(externalProp);
                externalProp.SetValue(panel, ConvertProperty(prop.Value, externalPropAttr.Converter), null);
            }
        }
    }

    private object ConvertProperty(string input, Type converter)
    {
        if (converter == null)
        {
            return input;
        }

        var converterInstance = (IConverter)Activator.CreateInstance(converter);
        return converterInstance.Convert(input);
    }
}