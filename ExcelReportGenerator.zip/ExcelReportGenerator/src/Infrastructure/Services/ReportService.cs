﻿using System.Diagnostics;
using Application.Customizations;
using ClosedXML.Excel;
using Domain.Reports;
using ExcelReportGenerator.Application.Reports.Model.Generic;
using Infrastructure.Rendering;

namespace ExcelReportGenerator.Infrastructure.Services
{
    public class ReportService
    {
        public ReportService() { }

        private static XLWorkbook GetReportTemplateWorkbook(string reportName)
        {
            return new XLWorkbook(Path.Combine("Reports", "Templates", $"{reportName}.xlsx"));
        }

        private static DefaultReportGenerator GetReportGenerator(Type reportType)
        {
            var report = GetReportInstance(reportType);
            return reportType == typeof(CustomReportGeneratorSample) ? new CustomReportGenerator(report) : new DefaultReportGenerator(report);
        }

        private static ReportBase GetReportInstance(Type reportType)
        {
            return (ReportBase)Activator.CreateInstance(reportType);
        }
        public async Task<string?> RenderToPdfReport(Type reportType,string reportName)
        {
            var file = await ReporteToBytes(reportType, reportName);
            if (file is not null)
                return Convert.ToBase64String(file); 

            return string.Empty;
        }

        public async Task<string?> RenderToExcelReport(Type reportType, string reportName)
        {
            var file = await ReporteToBytes(reportType,reportName);
            if (file is not null)
                return ConvertirConLibreOffice(file, "pdf");

            return string.Empty;
        }

        private async Task<byte[]?> ReporteToBytes(Type reportType, string reportName)
        {
            var reportGenerator = GetReportGenerator(reportType);
            try
            {
                await Task.Factory.StartNew(() =>
                {
                    using (var doc = new MemoryStream())
                    {
                        using (var plantilla = reportGenerator.Render(GetReportTemplateWorkbook(reportName)))
                        {
                            plantilla.SaveAs(doc);
                        }

                        return doc.ToArray();
                    }
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return null;
        }

        private static string ConvertirConLibreOffice(byte[] archivoBytes, string tipoArchivo)
        {
            string extension = tipoArchivo.ToLower();
            string tempInputPath = Path.Combine(Path.GetTempPath(), $"archivo.{extension}");
            string tempOutputPath = Path.Combine(Path.GetTempPath(), "archivo.pdf");

            try
            {
                // Escribir el archivo en un directorio temporal
                File.WriteAllBytes(tempInputPath, archivoBytes);

                // Ejecutar LibreOffice en modo headless para convertir a PDF
                var process = new Process
                {
                    StartInfo = new ProcessStartInfo
                    {
                        FileName = "libreoffice",
                        Arguments = $"--headless --convert-to pdf \"{tempInputPath}\" --outdir \"{Path.GetTempPath()}\"",
                        RedirectStandardOutput = true,
                        RedirectStandardError = true,
                        UseShellExecute = false,
                        CreateNoWindow = true
                    }
                };

                process.Start();
                process.WaitForExit();

                if (!File.Exists(tempOutputPath))
                {
                    var ex = new Exception("Error durante la conversión a PDF con LibreOffice.");
                    throw ex;
                }


                // Leer el archivo PDF resultante
                byte[] pdfBytes = File.ReadAllBytes(tempOutputPath);
                return Convert.ToBase64String(pdfBytes);
            }
            finally
            {
                // Limpiar archivos temporales
                if (File.Exists(tempInputPath)) File.Delete(tempInputPath);
                if (File.Exists(tempOutputPath)) File.Delete(tempOutputPath);
            }
        }
    }
}
