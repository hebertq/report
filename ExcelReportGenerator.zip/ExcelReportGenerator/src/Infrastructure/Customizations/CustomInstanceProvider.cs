﻿using Infrastructure.Rendering.Providers;

namespace Application.Customizations;

public class CustomInstanceProvider(object? defaultInstance = null) : DefaultInstanceProvider(defaultInstance)
{
    private readonly object _defaultInstance = defaultInstance!;

    public override object GetInstance(Type type)
    {
        return type == null ? _defaultInstance : Ioc.Container!.GetInstance(type);
    }

    public override T GetInstance<T>()
    {
        return (T)GetInstance(typeof(T));
    }
}