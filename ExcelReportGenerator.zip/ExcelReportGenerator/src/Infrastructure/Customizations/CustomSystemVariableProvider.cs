﻿using Infrastructure.Rendering.Providers.VariableProviders;

namespace Application.Customizations;

public class CustomSystemVariableProvider : SystemVariableProvider
{
    public string ReportTime => DateTime.Now.ToString("g");
}