﻿using Infrastructure.Rendering;

namespace Application.Customizations;

public class CustomSystemFunctions : SystemFunctions
{
    public static string ConvertGender(string gender) => gender == "M" ? "Male" : "Female";
}