﻿using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace PdfReportGenerator.Api.Filters
{
    /// <summary>
    /// 
    /// </summary>
    public class MarkdownOperationFilter : IOperationFilter
    {
        private readonly string _markdownFolder;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="markdownFolder"></param>
        /// <exception cref="ArgumentNullException"></exception>
        public MarkdownOperationFilter(string markdownFolder)
        {
            _markdownFolder = markdownFolder ?? throw new ArgumentNullException(nameof(markdownFolder));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="operation"></param>
        /// <param name="context"></param>
        public void Apply(OpenApiOperation operation, OperationFilterContext context)
        {
            // var version = context.DocumentName; // v1, v2 -> etc
            // var controllerName = context.MethodInfo.Name; // nombre del controlador

            if (operation == null || context == null)
            {
                return;
            }

            var controllerVersion = Path.Combine(context.DocumentName, context.MethodInfo!.DeclaringType!.Name);

            var markdownFilePath = Path.Combine(_markdownFolder, controllerVersion, $"{context.MethodInfo.Name}.md");

            var markdownContent = GetMarkdownContent(markdownFilePath);

            if (markdownContent != null)
            {
                // Extract summary and description from markdown content
                var summaryStartIndex = markdownContent.IndexOf("- **Summary**: ", StringComparison.OrdinalIgnoreCase);
                var descriptionStartIndex = markdownContent.IndexOf("- **Description**: ", StringComparison.OrdinalIgnoreCase);

                if (summaryStartIndex != -1 && descriptionStartIndex != -1)
                {
                    var summaryEndIndex = descriptionStartIndex;
                    var summaryLength = summaryEndIndex - (summaryStartIndex + "- **Summary**: ".Length);
                    operation.Summary = markdownContent.Substring(summaryStartIndex + "- **Summary**: ".Length, summaryLength).Trim();

                    var descriptionLength = markdownContent.Length - (descriptionStartIndex + "- **Description**: ".Length);
                    operation.Description = markdownContent.Substring(descriptionStartIndex + "- **Description**: ".Length, descriptionLength).Trim();
                }
            }
        }

        private string GetMarkdownContent(string filePath)
        {
            try
            {
                if (File.Exists(filePath))
                {
                    return File.ReadAllText(filePath);
                }
                else
                {
                    Console.WriteLine($"Markdown file not found: {filePath}");
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions (e.g., read error)
                Console.WriteLine($"Error reading Markdown file '{filePath}': {ex.Message}");
            }

            return string.Empty;
        }
    }
}
