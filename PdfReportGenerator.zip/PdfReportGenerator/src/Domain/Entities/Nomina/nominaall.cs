﻿
namespace PdfReportGenerator.Domain.Entities.Nomina
{
    public class nominaall
    {
        public string cedula { set; get; } = string.Empty;
        public string empleado { set; get; } = string.Empty;
        public decimal salbasico { set; get; } = 0;
        public decimal dias { set; get; } = 0;
        public decimal basico { set; get; } = 0;
        public decimal transporte { set; get; } = 0;
        public decimal bonocump { set; get; } = 0;
        public decimal he { set; get; } = 0;
        public decimal horaextra { set; get; } = 0;
        public decimal vacaciones { set; get; } = 0;
        public decimal otrosing { set; get; } = 0;
        public decimal totaldev { set; get; } = 0;
        public decimal inss { set; get; } = 0;
        public decimal otdeduc { set; get; } = 0;
        public decimal totalded { set; get; } = 0;
        public decimal neto { set; get; } = 0;
        public string firma { set; get; } = "";

        public static explicit operator List<object>(nominaall v)
        {
            throw new NotImplementedException();
        }
    }
}
