﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PdfReportGenerator.Domain.Entities.Nomina
{
    public class nominadesgefectivo
    {
        public string cedula { set; get; } = string.Empty;
        public string empleado { set; get; } = string.Empty;
        public decimal neto { set; get; } = 0;
        public decimal bi1000 { set; get; } = 0;
        public decimal bi500 { set; get; } = 0;
        public decimal bi200 { set; get; } = 0;
        public decimal bi100 { set; get; } = 0;
        public decimal bi50 { set; get; } = 0;
        public decimal bi20 { set; get; } = 0;
        public decimal bi10 { set; get; } = 0;
        public decimal bi5 { set; get; } = 0;
        public decimal bi1 { set; get; } = 0;
        public decimal bitotal { set; get; } = 0;
    }
}
