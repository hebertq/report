﻿namespace PdfReportGenerator.Domain.Entities.Nomina
{
    public class nominaalltarjeta
    {
        public string cedula { set; get; } = string.Empty;
        public string empleado { set; get; } = string.Empty;
        public decimal neto { set; get; } = 0;

    }
}
