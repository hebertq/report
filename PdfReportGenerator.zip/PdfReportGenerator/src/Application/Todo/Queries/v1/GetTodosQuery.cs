﻿using PdfReportGenerator.Application.Todo.Dto.v1;
using MediatR;

namespace PdfReportGenerator.Application.Todo.Queries.v1
{
    public class GetTodosQuery : IRequest<List<TodoDto>>
    {
    }
}
