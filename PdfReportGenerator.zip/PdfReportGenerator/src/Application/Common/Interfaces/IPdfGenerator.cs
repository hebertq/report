﻿namespace PdfReportGenerator.Application.Common.Interfaces
{
    public interface IPdfGenerator
    {
        string MyPrimerReporte();
    }
}
