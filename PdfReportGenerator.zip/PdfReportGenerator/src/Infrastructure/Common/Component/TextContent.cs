﻿using PdfReportGenerator.Infrastructure.Common.Interfaces;
using QuestPDF.Fluent;

namespace PdfReportGenerator.Infrastructure.Common.Component
{
// Clase para manejar texto
    public class TextContent : IContentElement
    {
        private string _text;
        private float _fontSize; 

        public TextContent(string text, float fontSize = 12, bool bold = false)
        {
            _text = text;
            _fontSize = fontSize;
        }

        public void Render(ColumnDescriptor container)
        {
            container.Item().Text(_text)
            .FontSize(_fontSize)
            .Bold();
        }
    }
}
