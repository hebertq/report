﻿using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace PdfReportGenerator.Infrastructure.Common.Component
{
    public class HeaderComponent : IComponent
    {
        private readonly string? _title;
        private readonly string? _name;
        private readonly string? _tipo;
        private readonly string? _detalleTipo;
        private readonly Image? _logoImage;

        public HeaderComponent(string? titulo, string? nombre, string? detalle, string? tipo, string? pathimage = null)
        {
            _title = titulo;
            _name = nombre;
            _tipo = tipo;
            _detalleTipo = detalle;

            // Validación para cargar la imagen solo si el path es válido
            if (!string.IsNullOrEmpty(pathimage) && File.Exists(pathimage))
            {
                _logoImage = Image.FromFile(pathimage);
            }
            else
            {
                _logoImage = null; // Si el path es nulo o el archivo no existe, no se carga la imagen
            }
        }

        public void Compose(IContainer container)
        {
            container.Row(row =>
            {
                // Si hay una imagen, la mostramos con un tamaño constante
                if (_logoImage is not null)
                    row.ConstantItem(130).Image(_logoImage);
                else
                    row.ConstantItem(130);

                // Definir el resto del encabezado sin la imagen
                row.RelativeItem().Column(column =>
                {
                    // Título principal centrado
                    column.Item().PaddingTop(5)
                        .AlignCenter()
                        .Text(_title)
                        .FontSize(17)
                        .SemiBold()
                        .FontColor(Colors.Black);

                    // Mostrar Tipo y DetalleTipo si existen
                    if (!string.IsNullOrEmpty(_tipo))
                    {
                        column.Item().AlignCenter().Text(text =>
                        {
                            if (!string.IsNullOrEmpty(_detalleTipo))
                            {
                                text.Span(_detalleTipo).Bold().FontSize(14); // Detalle
                            }
                            text.Span(_tipo).SemiBold().FontSize(14); // Tipo
                        });
                    }

                    // Nombre de la entidad centrado
                    if (!string.IsNullOrEmpty(_name))
                    {
                        column.Item().AlignCenter().Text(text =>
                        {
                            text.Span(_name).SemiBold().FontSize(13); // Nombre
                        });
                    }
                });

                // Espacio fijo a la derecha para asegurar el layout
                row.ConstantItem(120);
            });
        }
    }
}
