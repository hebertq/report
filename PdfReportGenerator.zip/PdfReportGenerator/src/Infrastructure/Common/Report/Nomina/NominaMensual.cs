﻿using PdfReportGenerator.Domain.Entities.Nomina;
using QuestPDF.Helpers;

namespace PdfReportGenerator.Infrastructure.Common.Report.Nomina
{
    public static class NominaMensual
    {
        public static string GenerarReporte() 
        {
            var data =  PoblarReporte();
            var headers = new Dictionary<string, int>
            {
                { "Cedula", 80},
                { "Nombre", 130 },
                { "Base", 40 },
                { "Dias", 30 },
                { "Basico", 40 },
                { "Trans", 35 },
                { "Cump", 35},
                { "C.He", 30},
                { "Extra", 35 },
                { "Vac", 35 },
                { "Oing", 35 },
                { "Total", 45 },
                { "Inss", 35 },
                { "O.duc", 35 },
                { "T.Ded", 45 },
                { "Neto", 45 },
                { "Firma", 80 }
            };

            var pdfGenerator = new PdfGenerator("DETALLE DE NOMINA","Del 01-01-2025 al 1501-2025  ","Desgloce de: ", "efectivo", null);

            foreach(var item in data.nominatotal)
            {
                var page = new PageGenerator();
                // Crear el contenido de la tabla
                page.AddTable(new TablaNomina(item, headers, false, true));
                pdfGenerator.PagesArray.Add(page);
            }         

            // Generar el PDF como base64
            return Convert.ToBase64String(pdfGenerator.GeneratePdf(PageSizes.A4.Portrait())!);
        }       

        public static repnominapago PoblarReporte()
        {
            List<nominatype> nominatypes = new List<nominatype>
            {
                new nominatype
                {
                     cedula = "123456789", 
                     empleado = "Juan Pérez", 
                     tipoempleado = "Tiempo Completo", 
                     salbasico = 1500,
                     dias = 30,
                     basico = 1500,
                     transporte = 100,
                     bonocump = 200,
                     he = 10,
                     horaextra = 50,
                     vacaciones = 100,
                     otrosing = 50,
                     totaldev = 2000,
                     inss = 50,
                     otdeduc = 20,
                     totalded = 70,
                     neto = 1930,
                     bi1000 = 1,
                     bi500 = 1,
                     bi200 = 0,
                     bi100 = 2,
                     bi50 = 1,
                     bi20 = 0,
                     bi10 = 0,
                     bi5 = 0,
                     bi1 = 0
                },
                new nominatype
                {
                     cedula = "987654321", 
                     empleado = "María López", 
                     tipoempleado = "Medio Tiempo", 
                     salbasico = 800,
                     dias = 15,
                     basico = 800,
                     transporte = 50,
                     bonocump = 100,
                     he = 5,
                     horaextra = 25,
                     vacaciones = 50,
                     otrosing = 20,
                     totaldev = 1045,
                     inss = 25,
                     otdeduc = 10,
                     totalded = 35,
                     neto = 1010,
                     bi1000 = 0,
                     bi500 = 2,
                     bi200 = 0,
                     bi100 = 1,
                     bi50 = 0,
                     bi20 = 2,
                     bi10 = 0,
                     bi5 = 1,
                     bi1 = 0
                },
                new nominatype
                {
                     cedula = "456789123", 
                     empleado = "Carlos Ruiz", 
                     tipoempleado = "Por Proyecto", 
                     salbasico = 0,
                     dias = 10,
                     basico = 500,
                     transporte = 20,
                     bonocump = 0,
                     he = 0,
                     horaextra = 10,
                     vacaciones = 0,
                     otrosing = 0,
                     totaldev = 520,
                     inss = 0,
                     otdeduc = 0,
                     totalded = 0,
                     neto = 520,
                     bi1000 = 0,
                     bi500 = 1,
                     bi200 = 1,
                     bi100 = 0,
                     bi50 = 0,
                     bi20 = 1,
                     bi10 = 0,
                     bi5 = 0,
                     bi1 = 0
                }
            };

            var reporte = new repnominapago
            {
                fecha_ini = "2025-01-01",
                fecha_fin = "2025-01-31", 
                titulo = "Reporte de Nómina - Enero 2025", 
                nominatotal = nominatypes.Select(n => new nominaall
                {
                     cedula     = n.cedula,
                     empleado   = n.empleado,
                     salbasico  = n.salbasico,
                     neto       = n.neto,
                     dias       = n.dias,      
                     basico     = n.basico ,   
                     transporte = n.transporte,
                     bonocump   = n.bonocump,  
                     he         = n.he,        
                     horaextra  = n.horaextra ,
                     vacaciones = n.vacaciones,
                     otrosing   = n.otrosing,  
                     totaldev   = n.totaldev,  
                     inss       = n.inss ,     
                     otdeduc    = n.otdeduc ,  
                     totalded   = n.totalded
                 }).ToList(),
                 desglocetarjeta = nominatypes
                 .Where(n => n.tipoempleado == "Tarjeta")
                 .Select(n => new nominaalltarjeta
                     {
                     cedula   = n.cedula,
                     empleado = n.empleado,
                     neto     = n.neto
                     }).ToList(),
                 desgloceefectivo = nominatypes
                 .Where(n => n.tipoempleado == "Efectivo")
                 .Select(n => new nominadesgefectivo
                     {
                     cedula = n.cedula,
                     empleado = n.empleado,
                     neto   = n.neto,
                     bi1000 = n.bi1000,
                     bi500 = n.bi500,
                     bi200 = n.bi200,
                     bi100 = n.bi100,
                     bi50 = n.bi50,
                     bi20 = n.bi20,
                     bi10 = n.bi10,
                     bi5 = n.bi5,
                     bi1 = n.bi1
                 }).ToList()
             };
             return reporte;
        }
    }
}
