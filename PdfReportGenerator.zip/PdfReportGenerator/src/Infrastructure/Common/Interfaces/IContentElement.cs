﻿using QuestPDF.Fluent;

namespace PdfReportGenerator.Infrastructure.Common.Interfaces
{
// Interfaz para los elementos de contenido
public interface IContentElement
{
void Render(ColumnDescriptor container);
}
}
