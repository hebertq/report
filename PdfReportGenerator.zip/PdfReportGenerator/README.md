# PdfReportGenerator

![Rest API](assets/LAFISE-REST_API-blue.svg) ![Lambda](assets/LAFISE-Lambda-orange.svg) ![dotnet](assets/USES-DOTNET8-831ae1.svg)

Describe your amazing project