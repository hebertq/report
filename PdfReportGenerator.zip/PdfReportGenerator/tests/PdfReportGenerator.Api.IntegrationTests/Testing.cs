﻿using System.Text.Json;
using System.Text.Json.Serialization;
using LAFISE.CrossCutting.Rest;
using LAFISE.CrossCutting.Rest.ErrorHandlers;
using Microsoft.Extensions.Logging;
using Yoh.Text.Json.NamingPolicies;

namespace PdfReportGenerator.Api.IntegrationTests
{
    [SetUpFixture]
    public class Testing
    {
        public static CustomWebApplicationFactory WebAppFactory = null!;

        public static TestRestApiService TestRestClient = null!;

        private static HttpClient _httpClient = null!;

        private static ILogger<RestApiService> _restClientLogger = null!;

        [OneTimeSetUp]
        public void SetUp()
        {
            Environment.SetEnvironmentVariable("IS_UNIT_TESTING", "True");

            // WebAppFactory executes Program in API layer
            WebAppFactory = new CustomWebApplicationFactory();

            //Creates a httpclient instance pointing to API layer
            _httpClient = WebAppFactory.CreateClient();

            _restClientLogger = new LoggerFactory().CreateLogger<RestApiService>();

            /*
             * Here you can customize TestRestApiService to be user throughout all the tests, for example, you
             * can change the logger or the ErrorHandler to suit your needs.
             *
             * See reference at: https://ni-cfl-dvps-1a.ni.lafise.corp/BLNI-Gerencia%20Sistemas%20Electronicos/LAFISE.CrossCutting/_wiki/wikis/LAFISE.CrossCutting%20Docs?wikiVersion=GBmaster&pagePath=%2Frest%2Ferror%20handling&pageId=41
             */
            TestRestClient = new TestRestApiService(_httpClient, _restClientLogger, new StandardApiErrorHandler(_restClientLogger));
        }

        [OneTimeTearDown]
        public void TearDown()
        {
            _httpClient?.Dispose();
            WebAppFactory.Dispose();
        }
    }
}
