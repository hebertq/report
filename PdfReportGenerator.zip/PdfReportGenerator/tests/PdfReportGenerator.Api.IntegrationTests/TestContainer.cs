﻿using DotNet.Testcontainers.Builders;
using DotNet.Testcontainers.Containers;

namespace PdfReportGenerator.IntegrationTests
{
    public static class TestContainer
    {
        /// <summary>
        /// Creates and starts a generic testcontainer with image name and container port.
        /// </summary>
        /// <remarks>
        /// Do not use if intended image already has a specific package with an specific initializer. i.e Sql Databases or LocalStack
        /// </remarks>
        /// <param name="image">Image Name (i.e. testcontainers/openbanking-sandbox)</param>
        /// <param name="containerPort">Public port of container to map</param>
        /// <param name="environmentVariables">Environment variables</param>
        /// <returns>Container instance</returns>
        public static async Task<IContainer> StartContainer(string image, int containerPort, Dictionary<string, string>? environmentVariables = null)
        {
            var container = new ContainerBuilder()
                .WithImage(image)
                .WithPortBinding(containerPort, true)
                .WithWaitStrategy(Wait.ForUnixContainer().UntilPortIsAvailable(containerPort))
                .WithEnvironment(environmentVariables)
                .Build();

            using var cts = new CancellationTokenSource(TimeSpan.FromMinutes(5));

            await container.StartAsync(cts.Token)
                .ConfigureAwait(false);

            return container;
        }
    }
}
