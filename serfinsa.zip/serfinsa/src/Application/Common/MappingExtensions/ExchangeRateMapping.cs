﻿using serfinsa.Domain.ApiContract.ExchangeRate.v1.Request;
using serfinsa.Domain.ApiContract.ExchangeRate.v1.Response;
using serfinsa.Domain.SoapContract.ExchangeRate.v1.Request;
using serfinsa.Domain.SoapContract.ExchangeRate.v1.Response;

namespace serfinsa.Application.Common.MappingExtensions
{
    public static class ExchangeRateMapping
    {
        public static RecuperaTCMes MapToRecuperaTCMes(this ExchangeRateRequest entity)
        {
            return new RecuperaTCMes
            {
                Ano = entity.Year,
                Mes = entity.Month
            };
        }
        public static List<ExchangeRateResponse> MapToExchangeRateList(this RecuperaTCMesResponse entity)
        {
            return entity.RecuperaTCMesResult.DetalleTC.Tc.Select(x => x.MapToExchangeRateSingle()).ToList();
        }
        public static ExchangeRateResponse MapToExchangeRateSingle(this Tc entity)
        {
            return new ExchangeRateResponse
            {
                Year = entity.Ano,
                Month = entity.Mes,
                Day = entity.Dia,
                Rate = entity.Valor
            };
        }
    }
}
