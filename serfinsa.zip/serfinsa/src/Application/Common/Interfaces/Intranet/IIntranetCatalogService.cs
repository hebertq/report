﻿using serfinsa.Domain.Common.Generic;
using serfinsa.Domain.Enums;

namespace serfinsa.Application.Common.Interfaces.Intranet
{
    public interface IIntranetCatalogService
    {
        Task<List<CatalogDetaiLl>> GetLocalEquivalencesByDetailCodeAsync(CatalogTypeEnum catalogType);
        Task<CatalogDetaiLl> GetGlobalEquivalenceByBankIdAndCoreCodeAsync(CatalogTypeEnum catalogType, string coreCode);
    }
}
