﻿using AutoMapper;

namespace serfinsa.Application.Common.Interfaces
{
    public interface IMapFrom<T> where T : class
    {
        void Mapping(Profile profile) => profile.CreateMap(typeof(T), GetType());
    }
}
