﻿using serfinsa.Domain.ApiContract.ExchangeRate.v1.Request;
using serfinsa.Domain.ApiContract.ExchangeRate.v1.Response;
using serfinsa.Domain.Common.Generic;

namespace serfinsa.Application.Common.Interfaces
{
    public interface IExchangeRateService
    {
        Task<Result<List<ExchangeRateResponse>>> GetExchangeRateOfMonth(ExchangeRateRequest requestSoap);
    }
}
