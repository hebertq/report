﻿using serfinsa.Domain.Entities.People;

namespace serfinsa.Application.Common.Interfaces.People
{
    public interface IIdentificationRepository
    {
        Task<Identification?> GetIdentificationByIdentificationOnly(string documentNumberHash);
        Task<List<Identification>?> GetIdentificationByPersonAndNumber(int personId);
    }
}
