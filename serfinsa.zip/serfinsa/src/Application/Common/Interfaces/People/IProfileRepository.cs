﻿using serfinsa.Application.People.Dto.v1;

namespace serfinsa.Application.Common.Interfaces.People
{
    public interface IProfileRepository
    {
        Task<ProfileDto?> GetProfileByBankIdAndCustomerNumber(int? companyId, int? customerNumber);
        Task<ProfileDto?> GetProfileByProfileIdOnly(int profileId);
        Task DeleteProfileDetail(int profileId);
    }
}
