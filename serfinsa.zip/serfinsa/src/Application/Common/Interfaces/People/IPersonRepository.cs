﻿using serfinsa.Domain.Entities.People;

namespace serfinsa.Application.Common.Interfaces.People
{
    public interface IPersonRepository
    {
        Task<Person> GetPersonByHashName(string personId);
        Task<Person> WriteBatchPerson(Person person);
        Task<Person> GetPersonById(int personId);
    }
}
