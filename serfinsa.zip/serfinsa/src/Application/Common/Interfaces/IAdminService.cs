﻿using serfinsa.Domain.Common.Generic;

namespace serfinsa.Application.Common.Interfaces
{
    public interface IAdminService
    {
        public Task<List<Combos>> GetAllOperaciones();
    }
}
