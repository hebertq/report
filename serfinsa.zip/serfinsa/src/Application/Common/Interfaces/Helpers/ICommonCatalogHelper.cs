﻿using serfinsa.Domain.Common.Generic;
using serfinsa.Domain.Enums;

namespace serfinsa.Application.Common.Interfaces.Helpers
{
    public interface ICommonCatalogHelper
    {
        Task<Dictionary<string, List<CatalogField>>> GetCatalogFieldsFromProperties<T>(T entity, CatalogProccesEnum process) where T : class;

        void PopulateEntityWithCatalogValues<T>(T entity, Dictionary<string, List<CatalogField>> catalogs,
            PersonProfileStatusEnum personProfile = PersonProfileStatusEnum.PS0) where T : class;
    }
}
