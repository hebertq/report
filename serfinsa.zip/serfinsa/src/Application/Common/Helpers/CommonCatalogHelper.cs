﻿using LAFISE.CrossCutting.Core.Exceptions;
using serfinsa.Application.Common.Interfaces.Helpers;
using serfinsa.Application.Common.Interfaces.Intranet;
using serfinsa.Domain.Attributes;
using serfinsa.Domain.Common.Generic;
using serfinsa.Domain.Enums;

namespace serfinsa.Application.Common.Helpers
{
    public class CommonCatalogHelper: ICommonCatalogHelper
    {
        private readonly IIntranetCatalogService _intranetCatalogService;

        public CommonCatalogHelper(IIntranetCatalogService intranetCatalogService)
        {
            _intranetCatalogService = intranetCatalogService;
        }

        public async Task<Dictionary<string, List<CatalogField>>> GetCatalogFieldsFromProperties<T>(T entity, CatalogProccesEnum process) where T : class
        {
            Dictionary<string, List<CatalogField>> catalogFields = new Dictionary<string, List<CatalogField>>();

            List<Task<Dictionary<string, List<CatalogField>>>> catalogTaskList = new();

            var catalogCodes = entity.GetType().GetProperties().Where(p => Attribute.IsDefined(p, typeof(CatalogCode))).ToList();

            foreach (var catalogCode in catalogCodes)
            {
                if (catalogCode.GetCustomAttributes(typeof(CatalogCode), true).FirstOrDefault() is CatalogCode catalogCodeAttribute
                    && catalogCode.GetValue(entity) is not null)
                {
                    if (catalogCode.PropertyType == typeof(string) && catalogCode.GetValue(entity) is string catalogCodeValue)
                    {                     
                        catalogTaskList.Add(Task.FromResult(new Dictionary<string, List<CatalogField>>() { { catalogCodeAttribute.TargetFieldName, new List<CatalogField> { await GetCatalogField(catalogCodeValue, catalogCodeAttribute.TargetFieldName, catalogCodeAttribute.CatalogType) } } }));
                    }
                    else if (catalogCode.PropertyType == typeof(List<string>) && catalogCode.GetValue(entity) is List<string> catalogCodeListValue)
                    {
                        catalogTaskList.Add(GetListCatalogField(catalogCodeListValue, catalogCodeAttribute.TargetFieldName, catalogCodeAttribute.CatalogType));
                    }
                }
            }

            var responses = (await Task.WhenAll(catalogTaskList)).ToList();

            foreach (Dictionary<string, List<CatalogField>> dictionary in responses)
            {
                foreach (KeyValuePair<string, List<CatalogField>> kvp in dictionary)
                {
                    catalogFields[kvp.Key] = kvp.Value;
                }
            }
            return catalogFields;
        }

        private static List<string> GetValidCatalogFieldsByProfile(PersonProfileStatusEnum profileStatusEnum)
        {
            List<string> fields = new List<string>() { "CountryOfIssuance", "IdentificationType", "BirthCountry" };
            if (profileStatusEnum >= PersonProfileStatusEnum.PS1)
                fields.AddRange(new List<string> { "Nationalities", "ResidenceCountry", "GeographicLocation", "EconomicActivity", "Title", "Occupation" });

            if (profileStatusEnum == PersonProfileStatusEnum.PS2)
                fields.AddRange(new List<string> { "MaritalStatus", "WorkEconomicActivity" });

            return fields;
        }

        public void PopulateEntityWithCatalogValues<T>(T entity, Dictionary<string, List<CatalogField>> catalogs,
            PersonProfileStatusEnum personProfile = PersonProfileStatusEnum.PS0) where T : class
        {
            var validFields = GetValidCatalogFieldsByProfile(personProfile);
            foreach (var prop in typeof(T).GetProperties()
                .Where(p => p.PropertyType == typeof(CatalogField) || p.PropertyType == typeof(List<CatalogField>)))
            {
                if (catalogs.ContainsKey(prop.Name) && validFields.Any(vf => vf == prop.Name) && catalogs[prop.Name] is List<CatalogField> value && value.Count >= 1)
                {
                    if (prop.PropertyType == typeof(CatalogField))
                        prop.SetValue(entity, value.FirstOrDefault());
                    else if (prop.PropertyType == typeof(List<CatalogField>))
                        prop.SetValue(entity, value);
                }
            }
        }

        private async Task<Dictionary<string, List<CatalogField>>> GetListCatalogField(List<string> catalogCodeValues, string fieldName, CatalogTypeEnum catalogType)
        {
            List<Task<CatalogField>> catalogFields = new();
            foreach (var val in catalogCodeValues)
            {
                catalogFields.Add(GetCatalogField(val, fieldName, catalogType));
            }
            return new Dictionary<string, List<CatalogField>>() { { fieldName, (await Task.WhenAll(catalogFields)).ToList() } };
        }

        private async Task<CatalogField> GetCatalogField(string code, string fieldName, CatalogTypeEnum catalogType)
        {
            var catalogDetailResponse = await _intranetCatalogService.GetGlobalEquivalenceByBankIdAndCoreCodeAsync(catalogType, code);

            if (catalogDetailResponse is null)
                throw new BadRequestException("400", $"'{code}' es un código {catalogType} no válido para el campo {fieldName}.", true);

            return await Task.FromResult(new CatalogField() { Code = code, Description = catalogDetailResponse.Description!,Id= catalogDetailResponse.Id });
        }
    }
}
