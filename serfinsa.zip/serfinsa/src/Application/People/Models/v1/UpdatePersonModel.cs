﻿using serfinsa.Domain.Attributes;
using serfinsa.Domain.Entities.People;
using serfinsa.Domain.Enums;

namespace serfinsa.Application.People.Models.v1
{
    public class UpdatePersonModel:PersonBase
    {
        #region Person
        /// <summary>
        /// The marital status code.
        /// </summary>
        [CatalogCode(CatalogTypeEnum.MaritalStatus)]
        public string? MaritalStatusCode { get; set; }

        /// <summary>
        /// Spouse data.
        /// </summary>
        public Spouse? Spouse { get; set; } = null!;

        /// <summary>
        /// The number of dependants.
        /// </summary>
        public int NumberOfDependants { get; set; }
        /// <summary>
        /// Pais de recidencia
        /// </summary>
        [CatalogCode(CatalogTypeEnum.Country)]
        public string? ResidenceCountryCode { get; set; }

        #endregion Person      

        #region Profile
        public PersonProfileStatusEnum ProfileType { get; set; }
        /// <summary>
        /// Person's address.
        /// </summary>
        public string? Address { get; set; }

        /// <summary>
        /// Geographic location code.
        /// </summary>
        [CatalogCode(CatalogTypeEnum.Region)]
        public string? RegionCode { get; set; }

        /// <summary>
        /// Person's phone number.
        /// </summary>
        public long? HomePhone { get; set; }

        /// <summary>
        /// Person's cell phone number.
        /// </summary>
        public long? CellPhone { get; set; } 

        /// <summary>
        ///  Person's email.
        /// </summary>
        public string? Email { get; set; }
        /// <summary>
        /// Person nationality
        /// </summary>
        [CatalogCode(CatalogTypeEnum.Country)]
        public string? NationalityCode { get; set; }
        /// <summary>
        /// Economic activity code.
        /// </summary>
        [CatalogCode(CatalogTypeEnum.EconomicActivity)]
        public string? EconomicActivityCode { get; set; }

        /// <summary>
        /// Job position.
        /// </summary>
        public JobInformation? jobDetail { get; set; }

        /// <summary>
        /// Ocupation code.
        /// </summary>
        [CatalogCode(CatalogTypeEnum.Occupation)]
        public string? OccupationCode { get; set; }

        /// <summary>
        /// Title code.
        /// </summary>
        [CatalogCode(CatalogTypeEnum.Title)]
        public string? TitleCode { get; set; }

        /// <summary>
        /// References of customer
        /// </summary>
        public List<Reference>? References { get; set; }

        /// <summary>
        /// Public Related Sector
        /// </summary>
        public PublicRelatedInformation? PublicRelated { get; set; }

        /// <summary>
        /// Economic Dependent 
        /// </summary>
        public EconomicDependentInformation? EconomicDependent { get; set; }

        /// <summary>
        /// Customer number.
        /// </summary>
        public int? CustomerNumber { get; set; }
        #endregion Profile

        #region Identification
        public DateOnly? IssueDateIdentification { get; set; }
        public DateOnly? ExpirationDateIdentification { get; set; }
        #endregion Identification
    }
}
