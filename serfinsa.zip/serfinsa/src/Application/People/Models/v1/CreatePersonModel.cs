﻿namespace serfinsa.Application.People.Models.v1
{
    public class CreatePersonModel : UpdatePersonModel
    {
        public long? GreenCard { get; set; }
    }
}
