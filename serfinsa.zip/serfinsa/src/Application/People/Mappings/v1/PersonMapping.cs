﻿using serfinsa.Application.People.Commands.v1;
using serfinsa.Domain.Common.Generic;
using serfinsa.Domain.Entities.People;

namespace serfinsa.Application.People.Mappings.v1
{
    public static class PersonMapping
    {
        public static Person MapToCreatePerson(this CreatePersonCommand entity, Dictionary<string, List<CatalogField>> catalogs)
        {
            return new Person()
            {
                PersonId           = entity.PersonId,
                FirstName          = entity.FirstName,
                SecondName         = entity.SecondName, 
                FirstLastName      = entity.FirstLastName, 
                SecondLastName     = entity.SecondLastName,
                BirthDate          = entity.BirthDate, 
                BirthCountry       = catalogs["BirthCountry"].FirstOrDefault(), 
                Gender             = catalogs["Gender"].FirstOrDefault()
            };
        }
    }
}
