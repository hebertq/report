﻿using serfinsa.Application.People.Dto.v1;
using serfinsa.Domain.Entities.People;

namespace serfinsa.Application.People.Mappings.v1
{
    public static class ProfileMapping
    {
        public static Profile MapToProfile(this ProfileDto entity)
        {
            return new Profile()
            {
                ProfileId = entity.ProfileId,
                ResidenceCountry = entity.ResidenceCountry,
                Spouse = entity.Spouse,
                Title = entity.Title,
                Occupation = entity.Occupation,
                EconomicActivity = entity.EconomicActivity,
                PublicRelated = entity.PublicRelated,
                EconomicDependent = entity.EconomicDependent,
                GreenCard = entity.GreenCard,
                jobDetail = entity.jobDetail,
                MaritalStatus = entity.MaritalStatus,
                NumberOfDependants = entity.NumberOfDependants,
                Region = entity.Region,
                Address = entity.Address,
                CellPhone = entity.CellPhone,
                HomePhone = entity.HomePhone,
                Email = entity.Email
            };                       
        }
    }
}
