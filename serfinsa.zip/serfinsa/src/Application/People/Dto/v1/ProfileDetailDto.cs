﻿using serfinsa.Domain.Entities.People;
using serfinsa.Domain.Enums;

namespace serfinsa.Application.People.Dto.v1
{
    public class ProfileDetailDto 
    {
        public int ProfileId { get; set; }
        public int? CustomerNumber { get; set; }
        public PersonProfileStatusEnum ProfileType { get; set; }
        public List<Reference>? References { get; set; }
    }
}
