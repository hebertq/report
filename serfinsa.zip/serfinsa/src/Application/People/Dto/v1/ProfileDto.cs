﻿using serfinsa.Domain.Common.Generic;
using serfinsa.Domain.Entities.People;

namespace serfinsa.Application.People.Dto.v1
{
    public class ProfileDto
    {
        public int ProfileId { get; set; }
        public CatalogField? MaritalStatus { get; set; }
        public CatalogField? ResidenceCountry { get; set; }
        public Spouse? Spouse { get; set; }
        public CatalogField? Title { get; set; }
        public CatalogField? Occupation { get; set; }
        public CatalogField? EconomicActivity { get; set; }
        public List<CatalogField>? Nationalities { get; set; }
        public PublicRelatedInformation? PublicRelated { get; set; }
        public EconomicDependentInformation? EconomicDependent { get; set; }      
        public long? GreenCard { get; set; }
        public JobInformation? jobDetail { get; set; }      
        public int? NumberOfDependants { get; set; }
        public CatalogField? Region { get; set; }
        public string? Address { get; set; }
        public long? CellPhone { get; set; }
        public long? HomePhone { get; set; }
        public string? Email { get; set; }
        public List<ProfileDetailDto>? Detail { get; set; }
    }
}
