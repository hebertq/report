﻿using serfinsa.Domain.Common.Generic;

namespace serfinsa.Application.People.Dto.v1
{
    public class CatalogValidDto
    {
        public CatalogField? BirthCountry { get; set; }
        public CatalogField? Gender { get; set; }
    }
}
