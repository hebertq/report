﻿using serfinsa.Domain.Common.Generic;

namespace serfinsa.Application.People.Dto.v1
{
    public class IdentificationDto
    {
        public CatalogField? CountryOfIssuance { get; set; }
        public CatalogField? IdentificationType { get; set; }
        public string? IdentificationNumber { get; set; }
        public DateOnly? IssueDate { get; set; }
        public DateOnly? ExpirationDate { get; set; }
    }
}
