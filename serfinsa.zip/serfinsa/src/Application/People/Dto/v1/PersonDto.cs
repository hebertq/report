﻿using serfinsa.Domain.Common.Generic;

namespace serfinsa.Application.People.Dto.v1
{
    public class PersonDto
    {
        public int PersonId { get; set; }     
        public string? FullName { get; set; }
        public string? FirstName { get; set; }
        public string? SecondName { get; set; }
        public string? FirstLastName { get; set; } 
        public string? SecondLastName { get; set; }
        public CatalogField? Sex { get; set; }
        public DateOnly? BirthDate { get; set; }       
        public CatalogField? BirthCountry { get; set; }      
        public IdentificationDto? Identification { get; set; }
        public ProfileDto? Profile { get; set; } = null!;
        
       
    }
}
