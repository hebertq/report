﻿using LAFISE.CrossCutting.Core.Exceptions;
using MediatR;
using serfinsa.Application.Common.Interfaces.People;
using serfinsa.Application.People.Commands.v1;
using serfinsa.Application.People.Common.Interfaces;
using serfinsa.Domain.Entities.People;

namespace serfinsa.Application.People.Handlers.Write.v1
{
    public class UpdatePersonCommandHandler:IRequestHandler<UpdatePersonCommand, Person>
    {
        private readonly IPersonRepository _personRepository;
        private readonly IIdentificationRepository _identificationRepository;
        private readonly IPersonGeneric _personRequestGeneric;
        public UpdatePersonCommandHandler(
            IPersonRepository personRepository, 
            IIdentificationRepository identificationRepository,
            IPersonGeneric personRequestGeneric)
        {
            _personRepository = personRepository;
            _identificationRepository = identificationRepository;
            _personRequestGeneric = personRequestGeneric;
        }

        public async Task<Person> Handle(UpdatePersonCommand request, CancellationToken cancellationToken)
        {
            string identificationKey = Identification.SkKeyBuilder(request.CountryOfIssuance, request.IdentificationType, request.Identification);
            
            // Validate identification           
            var identification = await _identificationRepository.GetIdentificationByIdentificationOnly(identificationKey);

            if (identification is null)
                throw new NotFoundException("Identificacion ingresada no existe");

            // Validate person
            var person = await _personRepository.GetPersonById(identification.PersonId);

            if (person is null)
                throw new BadRequestException("400", $"No se encontró registro de persona con identificación {request.Identification}", true);

            var personResponse = await _personRequestGeneric.PersonUpdateRequest(identification, person, request);
            return personResponse;
        }
    }
}
