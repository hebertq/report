﻿using LAFISE.CrossCutting.Core.Exceptions;
using MediatR;
using serfinsa.Application.Common.Interfaces.Helpers;
using serfinsa.Application.Common.Interfaces.People;
using serfinsa.Application.People.Commands.v1;
using serfinsa.Application.People.Mappings.v1;
using serfinsa.Domain.Entities.People;
using serfinsa.Domain.Enums;

namespace serfinsa.Application.People.Handlers.Write.v1
{
    public class CreatePersonCommandHandler : IRequestHandler<CreatePersonCommand, Person>
    {
        private readonly IPersonRepository _personRepository;
        private readonly IIdentificationRepository _identificationRepository;
        private readonly ICommonCatalogHelper _commonCatalogHelper;

        public CreatePersonCommandHandler(
            IPersonRepository personRepository,
            IIdentificationRepository identificationRepository,
            IProfileRepository profileRepository,
            ICommonCatalogHelper commonCatalogHelper)
        {
            _personRepository = personRepository;
            _identificationRepository = identificationRepository;  
            _commonCatalogHelper = commonCatalogHelper;
        }

        public async Task<Person> Handle(CreatePersonCommand request, CancellationToken cancellationToken)
        {
            Person? existingPerson;
            var catalogValues = await _commonCatalogHelper.GetCatalogFieldsFromProperties(request,CatalogProccesEnum.People);

            if (catalogValues is null) throw new BadRequestException("400", "Catalogos invalidos", true);

            var identificationKey = Identification.SkKeyBuilder(request.CountryOfIssuance, request.IdentificationType, request.Identification);
            var identificationPerson = await _identificationRepository.GetIdentificationByIdentificationOnly(identificationKey);
            var document = AddIdentification(request.CountryOfIssuance, request.IdentificationType, request.Identification, request.IssueDateIdentification, request.ExpirationDateIdentification);
            ProfileDetail profileDetail = new ProfileDetail()
            {
                ProfileType = request.ProfileType,
                References = request.References,
                CompanyId = request.ClientId,
                Document = document
            };

            if (identificationPerson is null)
            {               
                existingPerson = await _personRepository.GetPersonByHashName(request.NameToHash);
            }
            else
            {
                existingPerson = await _personRepository.GetPersonById(identificationPerson.PersonId);
            }            
            
            var person = request!.MapToCreatePerson(catalogValues);
            
            if (existingPerson is not null)
            {
                person.LastUpdate = DateTime.UtcNow;

                if (person.Profile!.Detail!.First(x => x.ProfileToHash.Equals(profileDetail.ProfileToHash) && x.Document!.DocumentNumberHash.Equals(identificationKey)) is null)
                    person.Profile!.Detail!.Add(profileDetail);

                if (request.ProfileType == PersonProfileStatusEnum.PS2)
                {                      
                    person.Profile!.Spouse = request.Spouse;
                    person.Profile!.NumberOfDependants = request.NumberOfDependants;
                }
            }
            else
            {               
                person.Identifications ??= [];
                person.Identifications.Add(document);                
                
                Profile profile = new() { Address = request.Address, HomePhone = request.HomePhone,CellPhone = request.CellPhone,Email = request.Email};
                profile.Detail ??= [profileDetail];
                profile.jobDetail = request.jobDetail;
                person.Profile = profile;
            }

            var personResponse = await _personRepository.WriteBatchPerson(person);
            return personResponse;
        }

        private Identification AddIdentification(string CountryOfIssuance,string IdentificationType, string Identification,DateOnly? IssueDate, DateOnly? ExpirationDate)
        {
            return new Identification()
            {
                CountryOfIssuance = CountryOfIssuance,
                IdentificationType = IdentificationType,
                IdentificationNumber = Identification,
                IssueDate = IssueDate,
                ExpirationDate = ExpirationDate
            };
        }
    }
}

