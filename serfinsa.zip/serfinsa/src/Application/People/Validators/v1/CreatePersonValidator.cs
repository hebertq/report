﻿using FluentValidation;
using serfinsa.Application.People.Commands.v1;
using serfinsa.Domain.Enums;
using serfinsa.Domain.Extensions;

namespace serfinsa.Application.People.Validators.v1
{
    public class CreatePersonValidator : AbstractValidator<CreatePersonCommand>
    {
        public CreatePersonValidator()
        {
            RuleFor(cp => cp.CountryOfIssuance)
                .NotNull().WithMessage("Se requiere el país de emisión del documento")
                .NotEmpty().WithMessage("Se requiere el país de emisión del documento");

            RuleFor(cp => cp.IdentificationType)
                .NotNull().WithMessage("Se requiere el tipo de documento")
                .NotEmpty().WithMessage("Se requiere el tipo de documento");

            RuleFor(cp => cp.Identification)
                .NotNull().WithMessage("Se requiere el número de documento")
                .NotEmpty().WithMessage("Se requiere el número de documento");

            RuleFor(cp => cp.AccessToken)
                .NotNull().WithMessage("Se requiere el token biométrico")
                .NotEmpty().WithMessage("Se requiere el token biométrico");

            RuleFor(cp => cp.ProfileType)
                .NotNull().WithMessage("Se requiere el estatus del perfil")
                .IsInEnum().WithMessage("Estado de perfil inválido");

            // Campos requeridos para perfil basico
            When(cp => cp.ProfileType >= PersonProfileStatusEnum.PS0, () =>
            {
                RuleFor(cp => cp.FirstName)
                    .NotNull().WithMessage("Se requiere el primer nombre")
                    .NotEmpty().WithMessage("Se requiere el primer nombre");

                RuleFor(cp => cp.FirstLastName)
                    .NotNull().WithMessage("Se requiere el primer apellido")
                    .NotEmpty().WithMessage("Se requiere el primer apellido");

                RuleFor(cp => cp.BirthDate)
                    .NotNull().WithMessage("Se requiere la fecha de nacimiento")
                    .NotEmpty().WithMessage("Se requiere la fecha de nacimiento");

                RuleFor(cp => cp.BirthDateCountryCode)
                    .NotNull().WithMessage("Se requiere el país de nacimiento")
                    .NotEmpty().WithMessage("Se requiere el país de nacimiento");

                RuleFor(cp => cp.Email)
                    .NotNull().WithMessage("Se requiere el correo electrónico")
                    .NotEmpty().WithMessage("Se requiere el correo electrónico")
                    .EmailAddress().WithMessage("Ingrese un correo válido");

                RuleFor(cp => cp.CellPhone.ToString())
                    .NotNull().WithMessage("Se requiere el número de celular")
                    .NotEmpty().WithMessage("Se requiere el número de celular")
                    .Matches(@"^\+[1-9]\d{1,14}$").WithMessage("Ingrese el número de teléfono en formato E.164");

            });

            // Campos requeridos para perfil intermedio
            When(cp => cp.ProfileType >= PersonProfileStatusEnum.PS1, () =>
            {
                RuleFor(cp => cp.ResidenceCountryCode)
                    .NotNull().WithMessage("Se requiere el país de residencia")
                    .NotEmpty().WithMessage("Se requiere el país de residencia");

                RuleFor(cp => cp.NationalityCode)
                    .NotNull().WithMessage("Se requiere la nacionalidad")
                    .NotEmpty().WithMessage("Se requiere la nacionalidad");

                RuleFor(cp => cp.IssueDateIdentification)
                    .NotNull().WithMessage("Se requiere la fecha de emisión del documento")
                    .NotEmpty().WithMessage("Se requiere la fecha de emisión del documento");

                RuleFor(cp => cp.ExpirationDateIdentification)
                    .NotNull().WithMessage("Se requiere la fecha de expiración del documento")
                    .NotEmpty().WithMessage("Se requiere la fecha de expiración del documento");

                RuleFor(cp => cp.Address)
                    .NotNull().WithMessage("Se requiere la dirección")
                    .NotEmpty().WithMessage("Se requiere la dirección");

                RuleFor(cp => cp.RegionCode)
                    .NotNull().WithMessage("Se requiere la ubicación geográfica")
                    .NotEmpty().WithMessage("Se requiere la ubicación geográfica");

                RuleFor(cp => cp.HomePhone.ToString())
                    .NotNull().WithMessage("Se requiere el número de teléfono")
                    .Matches(@"^\+[1-9]\d{1,14}$").When(x => !string.IsNullOrEmpty(x.HomePhone.ToString())).WithMessage("Ingrese el número de teléfono en formato E.164");

                RuleFor(cp => cp.EconomicActivityCode)
                    .NotNull().WithMessage("Se requiere la actividad económica")
                    .NotEmpty().WithMessage("Se requiere la actividad económica");

                RuleFor(cp => cp.TitleCode)
                    .NotNull().WithMessage("Se requiere el titulo")
                    .NotEmpty().WithMessage("Se requiere el titulo");

                RuleFor(cp => cp.OccupationCode)
                    .NotNull().WithMessage("Se requiere la ocupación")
                    .NotEmpty().WithMessage("Se requiere la ocupación");
            });

            // Campos requeridos para perfil completo
            When(cp => cp.ProfileType == PersonProfileStatusEnum.PS2, () =>
            {
                RuleFor(cp => cp.MaritalStatusCode)
                    .NotNull().WithMessage("Se requiere el estado civil")
                    .NotEmpty().WithMessage("Se requiere el estado civil");

                When(cp => cp.MaritalStatusCode!.ParseEnum<MaritalStatusEnum>().In(MaritalStatusEnum.CAS, MaritalStatusEnum.ULI, MaritalStatusEnum.COH), () =>
                {
                    RuleFor(cp => cp.Spouse)
                            .NotNull().WithMessage("Se requiere la información del cónyuge")
                            .NotEmpty().WithMessage("Se requiere el información del cónyuge");
                });

                RuleFor(cp => cp.NumberOfDependants)
                .NotNull().WithMessage("Se requiere el número de dependientes");

                RuleFor(cp => cp.jobDetail)
                    .NotNull().WithMessage("Se requiere la información laboral")
                    .NotEmpty().WithMessage("Se requiere la información laboral");

                RuleFor(cp => cp.jobDetail!.WorkPlace)
                    .NotNull().WithMessage("Se requiere el lugar de trabajo")
                    .NotEmpty().WithMessage("Se requiere el lugar de trabajo");

                RuleFor(cp => cp.jobDetail!.WorkEconomicActivityCode)
                    .NotNull().WithMessage("Se requiere la actividad económica laboral")
                    .NotEmpty().WithMessage("Se requiere la actividad económica laboral");

                RuleFor(cp => cp.jobDetail!.WorkPhone.ToString())
                    .NotEmpty().WithMessage("El teléfono de trabajo no puede estar vacio")
                    .Matches(@"^\+[1-9]\d{1,14}$").When(x => !string.IsNullOrEmpty(x.jobDetail!.WorkPhone.ToString())).WithMessage("Ingrese el número de teléfono en formato E.164");

                RuleFor(cp => cp.jobDetail!.WorkEmail)
                    .NotEmpty().WithMessage("El correo de trabajo no puede estar vacio")
                    .EmailAddress().When(x => !string.IsNullOrEmpty(x.jobDetail!.WorkEmail)).WithMessage("Ingrese un correo válido");

                RuleFor(cp => cp.jobDetail!.MonthlyIncome)
                    .NotNull().WithMessage("Se requiere el ingreso mensual")
                    .NotEmpty().WithMessage("Se requiere el ingreso mensual");
            });
        }
    }
}

