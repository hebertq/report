﻿using MediatR;
using serfinsa.Application.People.Models.v1;
using serfinsa.Domain.Attributes;
using serfinsa.Domain.Entities.People;
using serfinsa.Domain.Enums;

namespace serfinsa.Application.People.Commands.v1
{
    public class CreatePersonCommand: CreatePersonModel, IRequest<Person>
    {
        public int ClientId { get; set; } = 1;
        [CatalogCode(CatalogTypeEnum.Country, "CountryOfIssuance")]
        public string CountryOfIssuance { get; set; } = null!;
        [CatalogCode(CatalogTypeEnum.IdentificationType)]
        public string IdentificationType { get; set; } = null!;
        public string Identification { get; set; } = null!;
        public new PersonProfileStatusEnum? ProfileType { get; set; }
        public string AccessToken { get; set; } = null!;
    }
}
