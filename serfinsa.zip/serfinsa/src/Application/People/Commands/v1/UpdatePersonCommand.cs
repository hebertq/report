﻿using MediatR;
using serfinsa.Application.People.Models.v1;
using serfinsa.Domain.Entities.People;
using serfinsa.Domain.Enums;

namespace serfinsa.Application.People.Commands.v1
{
    public class UpdatePersonCommand : UpdatePersonModel, IRequest<Person>
    {
        public string CountryOfIssuance { get; set; } = null!;
        public string IdentificationType { get; set; } = null!;
        public string Identification { get; set; } = null!;
        public new PersonProfileStatusEnum ProfileType { get; set; } = PersonProfileStatusEnum.PS0;
        public string AccessToken { get; set; } = null!;
    }
}
