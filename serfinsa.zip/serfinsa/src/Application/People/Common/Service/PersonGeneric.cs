﻿using LAFISE.CrossCutting.Core.Exceptions;
using Microsoft.Extensions.Logging;
using serfinsa.Application.Common.Interfaces.Helpers;
using serfinsa.Application.Common.Interfaces.People;
using serfinsa.Application.People.Common.Interfaces;
using serfinsa.Application.People.Mappings.v1;
using serfinsa.Application.People.Models.v1;
using serfinsa.Domain.Entities.People;
using serfinsa.Domain.Enums;

namespace serfinsa.Application.People.Common.Service
{
    public class PersonGeneric: IPersonGeneric
    {
        private readonly ILogger<PersonGeneric> _logger;
        private readonly IProfileRepository _profileRepository;
        private readonly IPersonRepository _personRepository;
        private readonly ICommonCatalogHelper _commonCatalogHelper;
        public PersonGeneric(
            ILogger<PersonGeneric> logger,
            IProfileRepository profileRepository,
            IPersonRepository personRepository,
            ICommonCatalogHelper commonCatalogHelper
            )
        {
            _logger = logger;
            _profileRepository = profileRepository;
            _personRepository = personRepository;
            _commonCatalogHelper = commonCatalogHelper;
        }

        /// <summary>
        /// Person update request
        /// </summary>
        /// <param name="identification"></param>
        /// <param name="person"></param>
        /// <param name="request"></param>
        /// <returns></returns>       
        public async Task<Person> PersonUpdateRequest(Identification identification, Person person, UpdatePersonModel request)
        {
            // Lookup for catalog values
            var catalogValues = await _commonCatalogHelper.GetCatalogFieldsFromProperties(request, CatalogProccesEnum.People);

            _commonCatalogHelper.PopulateEntityWithCatalogValues(person, catalogValues, request.ProfileType);

            // Validate profile          
            var profileRecords = await _profileRepository.GetProfileByBankIdAndCustomerNumber(request.CompanyId, request.CustomerNumber);
            if (profileRecords is null)
                throw new BadRequestException("400", $"No se encontró perfíl de persona con identificación {identification.IdentificationNumber} en el pais {identification.CountryOfIssuance}.", true);

            var currentProfile = profileRecords.Detail!.Max(x=> x.ProfileType);

            // Validate the CIF only if the person is currently a PS2 profile.
            if (currentProfile == PersonProfileStatusEnum.PS2)
            {
                if (!profileRecords.Detail!.Exists(x=> x.CustomerNumber == request.CustomerNumber))
                    throw new BadRequestException("400", $"No se encontró perfíl de persona con CIF {request.CustomerNumber} en el pais {identification.CountryOfIssuance}.", true);
            }

            var profileData = profileRecords.MapToProfile();
            profileRecords.Detail!.ForEach(
                profile => _commonCatalogHelper.PopulateEntityWithCatalogValues(profile, catalogValues, request.ProfileType));

            switch (request.ProfileType)
            {
                case PersonProfileStatusEnum.PS0:
                    UpdateProfilesInformation(profileData, request);
                    break;

                case PersonProfileStatusEnum.PS1:
                    UpdateBasicManagerProfileInformation(person, identification, profileData!, request);
                    break;

                case PersonProfileStatusEnum.PS2:
                    UpdateSimplifiedCustomerProfileInformation(person, identification,profileData!, request);
                    break;

                default:
                    break;
            }

            // Profile PS2
            if (currentProfile == PersonProfileStatusEnum.PS1 && request.ProfileType == PersonProfileStatusEnum.PS2)
            {
                //Delete profiles
                profileData.Detail!.ForEach(
                    profile =>
                    {
                        if (profile.ProfileType == PersonProfileStatusEnum.PS0)
                            _profileRepository.DeleteProfileDetail(profile.ProfileId);
                    });

                // New profile
                var newProfile = profileData.Detail.First();
                newProfile.CustomerNumber = request.CustomerNumber;
                newProfile.Created = DateTime.UtcNow;
                newProfile.LastUpdate = DateTime.UtcNow;
                newProfile.ProfileType = PersonProfileStatusEnum.PS2;
                profileData.Detail.Add(newProfile);
            }

            return await UpdatePersonDataBase(person, identification, profileData);
        }

        /// <summary>
        /// Update profiles information
        /// </summary>
        /// <param name="profiles"></param>
        /// <param name="request"></param>
        /// <returns></returns>
        private static void UpdateProfilesInformation(Profile profile, UpdatePersonModel request)
        {
            if (request.ProfileType == PersonProfileStatusEnum.PS0)
            {
                profile.Email = request.Email;
                profile.CellPhone = request.CellPhone;
            }

            if (request.ProfileType == PersonProfileStatusEnum.PS1)
            {
                profile.Email = request.Email;
                profile.CellPhone = request.CellPhone;
                profile.Address = request.Address;
                profile.HomePhone = request.HomePhone;
            }

            if (request.ProfileType == PersonProfileStatusEnum.PS2)
            {
                profile.Email = request.Email;
                profile.CellPhone = request.CellPhone;
                profile.Address = request.Address;
                profile.HomePhone = request.HomePhone;
                profile.jobDetail ??= new();
                profile.jobDetail = request.jobDetail!;                
            }

            profile.LastUpdate = DateTime.UtcNow;
            profile.CompanyId = request.CompanyId;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="person"></param>
        /// <param name="identification"></param>
        /// <param name="profiles"></param>
        /// <param name="request"></param>
        /// <returns></returns>
        private static void UpdateBasicManagerProfileInformation(Person person, Identification identification, Profile profile, UpdatePersonModel request)
        {
            // Update Person         
            person.LastUpdate = DateTime.UtcNow;
            person.CompanyId = request.CompanyId;

            //// Update Identification
            person.Identifications!.ForEach(
                    item =>
                    {
                        if (item.IdentificationNumber == identification.IdentificationNumber)
                        {
                            item.IssueDate = identification.IssueDate;
                            item.ExpirationDate = identification.ExpirationDate;
                        }
                    });

            // Update Profiles
            UpdateProfilesInformation(profile, request);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="person"></param>
        /// <param name="identification"></param>
        /// <param name="profiles"></param>
        /// <param name="request"></param>
        /// <returns></returns>
        private static void UpdateSimplifiedCustomerProfileInformation(Person person, Identification identification,Profile profile, UpdatePersonModel request)
        {
            // Update basic profile
            UpdateBasicManagerProfileInformation(person, identification, profile, request);

            profile.NumberOfDependants = request.NumberOfDependants;
            profile.Spouse = request.Spouse;
            profile.MaritalStatus = profile.MaritalStatus!;
        }
        /// <summary>
        /// Atualizar personas
        /// </summary>
        /// <param name="person"></param>
        /// <param name="identification"></param>
        /// <param name="profiles"></param>   
        /// <returns></returns>
        private async Task<Person> UpdatePersonDataBase(Person person, Identification identification, Profile profile)
        {
            person.Identifications ??= [];
            person.Identifications!.Add(identification);
            person.Profile = profile;

            var personResponse = await _personRepository.WriteBatchPerson(person);           
            return personResponse;
        }
    }
}
