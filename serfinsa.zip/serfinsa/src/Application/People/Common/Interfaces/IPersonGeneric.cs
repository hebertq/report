﻿using serfinsa.Application.People.Models.v1;
using serfinsa.Domain.Entities.People;

namespace serfinsa.Application.People.Common.Interfaces
{
    public interface IPersonGeneric
    {
        Task<Person> PersonUpdateRequest(Identification identification, Person person, UpdatePersonModel request);
    }
}
