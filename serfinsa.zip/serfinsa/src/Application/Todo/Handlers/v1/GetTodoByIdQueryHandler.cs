﻿using AutoMapper;
using LAFISE.CrossCutting.Core.Exceptions;
using serfinsa.Application.Common.Interfaces;
using serfinsa.Application.Todo.Dto.v1;
using serfinsa.Application.Todo.Queries.v1;
using MediatR;

namespace serfinsa.Application.Todo.Handlers.v1
{
    public class GetTodoByIdQueryHandler : IRequestHandler<GetTodoByIdQuery, TodoDto>
    {
        private readonly ITodoService _todoService;
        private readonly IMapper _mapper;

        public GetTodoByIdQueryHandler(ITodoService todoService, IMapper mapper)
        {
            _todoService = todoService;
            _mapper = mapper;
        }

        public async Task<TodoDto> Handle(GetTodoByIdQuery request, CancellationToken cancellationToken)
        {
            var todo = await _todoService.GetTodoById(request.Id);

            if (todo is null)
                throw new NotFoundException($"The todo with id {request.Id} doesn't exist");

            return _mapper.Map<TodoDto>(todo);
        }
    }
}
