﻿using AutoMapper;
using MediatR;
using serfinsa.Application.Common.Interfaces;
using serfinsa.Application.Todo.Dto.v1;
using serfinsa.Application.Todo.Queries.v1;
using serfinsa.Domain.ApiContract.ExchangeRate.v1.Request;

namespace serfinsa.Application.Todo.Handlers.v1
{
    public class GetTodosQueryHandler : IRequestHandler<GetTodosQuery, List<TodoDto>>
    {
        private readonly ITodoService _todoService;
        private readonly IMapper _mapper;
        private readonly IAdminService _adminService;
        private readonly IExchangeRateService _exchangeRateService;

        public GetTodosQueryHandler(ITodoService todoService, IMapper mapper, IAdminService adminservice, IExchangeRateService exchangeRateService)
        {
            _todoService = todoService;
            _mapper = mapper;
            _adminService = adminservice;
            _exchangeRateService = exchangeRateService;
        }

        public async Task<List<TodoDto>> Handle(GetTodosQuery request, CancellationToken cancellationToken)
        {
            var cambio = new ExchangeRateRequest() { Year = 2024, Month = 8 };
            var todos = await _todoService.GetTodos();
            var datos = await _exchangeRateService.GetExchangeRateOfMonth(cambio);
            var data = await _adminService.GetAllOperaciones();
            return _mapper.Map<List<TodoDto>>(todos);
        }
    }
}
