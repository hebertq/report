﻿using AutoMapper;
using serfinsa.Application.Common.Interfaces;
using serfinsa.Application.Todo.Commands.v1;
using serfinsa.Application.Todo.Dto.v1;
using serfinsa.Domain.Entities.Todos;
using MediatR;

namespace serfinsa.Application.Todo.Handlers.v1
{
    public class CreateTodoCommandHandler : IRequestHandler<CreateTodoCommand, TodoDto>
    {
        private readonly ITodoService _todoService;
        private readonly IMapper _mapper;

        public CreateTodoCommandHandler(ITodoService todoService, IMapper mapper)
        {
            _todoService = todoService;
            _mapper = mapper;
        }

        public async Task<TodoDto> Handle(CreateTodoCommand request, CancellationToken cancellationToken)
        {
            var response = await _todoService.CreateTodo(_mapper.Map<TodoEntity>(request));

            return _mapper.Map<TodoDto>(response);
        }
    }
}
