﻿using serfinsa.Application.Todo.Dto.v1;
using MediatR;

namespace serfinsa.Application.Todo.Queries.v1
{
    public class GetTodosQuery : IRequest<List<TodoDto>>
    {
    }
}
