﻿using FluentValidation;
using serfinsa.Application.Todo.Queries.v1;

namespace serfinsa.Application.Todo.Validators.v1
{
    public class GetTodoByIdValidator : AbstractValidator<GetTodoByIdQuery>
    {
        public GetTodoByIdValidator()
        {
            RuleFor(ct => ct.Id)
                .NotEmpty()
                .NotNull();
        }
    }
}
