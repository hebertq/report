﻿using System.Xml.Serialization;

namespace serfinsa.Domain.SoapContract.ExchangeRate.v1.Request
{
    [XmlRoot(ElementName = "RecuperaTC_Mes")]
    public class RecuperaTCMes
    {

        [XmlElement(ElementName = "Ano")]
        public int Ano { get; set; }

        [XmlElement(ElementName = "Mes")]
        public int Mes { get; set; }
    }
}
