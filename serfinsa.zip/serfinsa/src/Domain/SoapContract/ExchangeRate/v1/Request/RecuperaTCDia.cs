﻿using System.Xml.Serialization;

namespace serfinsa.Domain.SoapContract.ExchangeRate.v1.Request
{
    [XmlRoot(ElementName = "RecuperaTC_Dia")]
    public class RecuperaTCDia
    {
        [XmlElement(ElementName = "Ano")]
        public int Ano { get; set; }

        [XmlElement(ElementName = "Mes")]
        public int Mes { get; set; }

        [XmlElement(ElementName = "Dia")]
        public int Dia { get; set; }

        [XmlAttribute(AttributeName = "xmlns")]
        public string Xmlns { get; set; }

        [XmlText]
        public string Text { get; set; }
    }
}
