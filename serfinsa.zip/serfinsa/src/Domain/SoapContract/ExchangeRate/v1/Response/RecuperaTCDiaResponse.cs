﻿using System.Xml.Serialization;

namespace serfinsa.Domain.SoapContract.ExchangeRate.v1.Response
{
    [XmlRoot(ElementName = "RecuperaTC_DiaResponse")]
    public class RecuperaTCDiaResponse
    {

        [XmlElement(ElementName = "RecuperaTC_DiaResult")]
        public double RecuperaTCDiaResult { get; set; }
    }
}
