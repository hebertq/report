﻿using System.Xml.Serialization;

namespace serfinsa.Domain.SoapContract.ExchangeRate.v1.Response
{
    [XmlRoot(ElementName = "Detalle_TC")]
    public class DetalleTC
    {
        [XmlElement(ElementName = "Tc")]
        public List<Tc> Tc { get; set; }
    }
}
