﻿using System.Xml.Serialization;

namespace serfinsa.Domain.SoapContract.ExchangeRate.v1.Response
{
    [XmlRoot(ElementName = "Tc")]
    public class Tc
    {
        [XmlElement(ElementName = "Fecha")]
        public DateTime Fecha { get; set; }

        [XmlElement(ElementName = "Valor")]
        public double Valor { get; set; }

        [XmlElement(ElementName = "Ano")]
        public int Ano { get; set; }

        [XmlElement(ElementName = "Mes")]
        public int Mes { get; set; }

        [XmlElement(ElementName = "Dia")]
        public int Dia { get; set; }
    }
}
