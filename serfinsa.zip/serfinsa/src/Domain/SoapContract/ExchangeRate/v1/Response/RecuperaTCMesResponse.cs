﻿using System.Xml.Serialization;

namespace serfinsa.Domain.SoapContract.ExchangeRate.v1.Response
{
    [XmlRoot(ElementName = "RecuperaTC_MesResponse")]
    public class RecuperaTCMesResponse
    {
        [XmlElement(ElementName = "RecuperaTC_MesResult")]
        public RecuperaTCMesResult RecuperaTCMesResult { get; set; }
    }
}
