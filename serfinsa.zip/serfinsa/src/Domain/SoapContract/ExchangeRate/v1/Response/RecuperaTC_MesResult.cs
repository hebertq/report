﻿using System.Xml.Serialization;

namespace serfinsa.Domain.SoapContract.ExchangeRate.v1.Response
{
    [XmlRoot(ElementName = "RecuperaTC_MesResult")]
    public class RecuperaTCMesResult
    {

        [XmlElement(ElementName = "Detalle_TC")]
        public DetalleTC DetalleTC { get; set; }
    }
}
