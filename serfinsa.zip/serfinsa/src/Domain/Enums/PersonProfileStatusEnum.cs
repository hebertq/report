﻿using System.ComponentModel;

namespace serfinsa.Domain.Enums
{
    public enum PersonProfileStatusEnum
    {
        [Description("PS0")]
        PS0,
        [Description("PS1")]
        PS1,
        [Description("PS2")]
        PS2
    }
}
