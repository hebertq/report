﻿using System.ComponentModel;

namespace serfinsa.Domain.Enums
{
    public enum MaritalStatusEnum
    {
        [Description("Soltero")]
        SOL = 1,
        [Description("Casado")]
        CAS,
        [Description("Union libre")]
        ULI,
        [Description("Niudo")]
        VIU,
        [Description("Cohabitando")]
        COH,
        [Description("Otro")]
        OTR
    }
}

