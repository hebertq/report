﻿namespace serfinsa.Domain.Enums
{
    public enum CatalogProccesEnum :int
    {
        People = 1,
        Admin
    }
}
