﻿namespace serfinsa.Domain.Enums
{
    public enum StatusResponse
    {
        OK,
        UnexpectedError,
        NoData,
        ValidationError,
        NoPermission,
        UnSuccess,
        InternalServerError,
        BadRequest,
        NotFound,
        Unauthorized
    }
}
