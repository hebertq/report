﻿namespace serfinsa.Domain.Enums
{
    public enum CatalogTypeEnum:int
    {
        Country,
        IdentificationType,
        MaritalStatus,
        EconomicActivity,
        Industry,
        Occupation,
        GeographicLocation,
        Title,
        Sector,
        Gender,
        Region
    }
}
