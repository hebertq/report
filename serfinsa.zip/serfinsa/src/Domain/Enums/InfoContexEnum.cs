﻿namespace serfinsa.Domain.Enums
{  
    public enum InfoContexEnum
    {
        Odoo,
        SFCore,
        Admin
    }
}
