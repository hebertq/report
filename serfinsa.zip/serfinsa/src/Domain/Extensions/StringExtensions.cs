﻿using System.Globalization;
using System.Security.Cryptography;
using System.Text;

namespace serfinsa.Domain.Extensions
{
    public static class StringExtensions
    {
        /// <summary>
        /// Converts a string value into a long value
        /// </summary>
        /// <param name="s">this string value</param>
        /// <returns>The long value, 0 if parsing fails</returns>
        public static long ParseLong(this string s)
        {
            return long.TryParse(s, out long result) ? result : 0;
        }

        /// <summary>
        /// Converts a string value into a int value
        /// </summary>
        /// <param name="s">this string value</param>
        /// <returns>The int value, 0 if parsing fails</returns>
        public static int ParseInt(this string s)
        {
            return int.TryParse(s, out int result) ? result : 0;
        }

        /// <summary>
        /// Converts a string value into a decimal value
        /// </summary>
        /// <param name="s">this string value</param>
        /// <returns>The decimal value, 0 if parsing fails</returns>
        public static decimal ParseDecimal(this string s)
        {
            return decimal.TryParse(s, out decimal result) ? result : 0;
        }

        /// <summary>
        /// Gets the error code from an AS400 SQL State response
        /// </summary>
        /// <param name="errorCode">this string to cast</param>
        /// <returns>The error code, empty if not valid</returns>
        public static string GetErrorCode(this string errorCode)
        {
            if (string.IsNullOrEmpty(errorCode))
                return string.Empty;

            return errorCode[..1].Equals("E") ? errorCode[1..].ParseInt().ToString() : errorCode;
        }

        /// <summary>
        /// Gets the error message from an AS400 SQL State response
        /// </summary>
        /// <param name="errorMessage">this string to cast</param>
        /// <returns>The error message, default message if not valid</returns>
        public static string GetErrorMessage(this string errorMessage)
        {
            var mensajeTemp = errorMessage.Split(']');
            return mensajeTemp.Length > 1 ? mensajeTemp[1] : "Ha ocurrido un error, por favor intente nuevamente.";
        }

        /// <summary>
        /// Fold first letter of every word to uppercase
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public static string UppercaseFirstLetter(string s)
        {
            if (string.IsNullOrEmpty(s))
            {
                return string.Empty;
            }

            StringBuilder output = new StringBuilder();
            string[] words = s.Split(' ');
            foreach (string word in words)
            {
                char[] a = word.ToCharArray();
                a[0] = char.ToUpper(a[0]);
                string b = new string(a);
                output.Append(b + " ");
            }

            return output.ToString().Trim();
        }
        /// <summary>
        /// Validar si el texto esta en mayusculas
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static Boolean UppercasetLetter(string data)
        {
            if (string.IsNullOrEmpty(data))
            {
                return false;
            }

            string opertname = data.ToUpperInvariant();
            if (data == opertname)
                return true;
            else
                return false;
        }

        /// <summary>
        /// Returns the left part of this string instance.
        /// </summary>
        /// <param name="count">Number of characters to return.</param>
        public static string Left(this string input, int count)
        {
            return input.Substring(0, Math.Min(input.Length, count));
        }
        /// <summary>
        /// Returns the right part of the string instance.
        /// </summary>
        /// <param name="count">Number of characters to return.</param>
        public static string Right(this string input, int count)
        {
            return input.Substring(Math.Max(input.Length - count, 0), Math.Min(count, input.Length));
        }
        /// <summary>
        /// Quitar los dobles espacios de una cadena de texto		
        /// </summary>
        /// <param name="pCadenaTexto">Cadena de texto que contiene dobles espacios</param>
        /// <returns>Cadena de Texto o nulo de recibir cadena nula</returns>
        public static string QuitarDoblesEspacios(string pCadenaTexto)
        {
            if (string.IsNullOrEmpty(pCadenaTexto))
                return pCadenaTexto;

            while (pCadenaTexto.Contains("  "))
            {
                pCadenaTexto = pCadenaTexto.Replace("  ", " ");

            }
            return pCadenaTexto.Trim();
        }

        public static string Get4LetterYear(int twoLetterYear)
        {
            int TwoDigits = Convert.ToInt32(DateTime.Now.Year.ToString().Substring(2, 2));
            int firstDigits = Convert.ToInt32(DateTime.Now.Year.ToString().Substring(0, 2));
            return Get4LetterYear(twoLetterYear, twoLetterYear <= TwoDigits ? firstDigits : firstDigits - 1).ToString();
        }

        public static int Get4LetterYear(int twoLetterYear, int firstTwoDigits)
        {
            return Convert.ToInt32(firstTwoDigits.ToString() + twoLetterYear.ToString());
        }

        public static string ToSnakeCase(this string str)
        {
            return string.Concat(str.Select((x, i) => i > 0 && char.IsUpper(x) ? "_" + x.ToString() : x.ToString())).ToLower();
        }
        public static string AddSpaceIfNotNull(this string? str)
        {
            return (str is not null) ? $"{str.ToUpper()} " : string.Empty;
        }
        public static string GetStringHash(this string input, string salt)
        {
            byte[] saltBytes = Encoding.UTF8.GetBytes(salt);
            byte[] inputBytes = Encoding.UTF8.GetBytes(input);

            byte[] saltedInputBytes = new byte[saltBytes.Length + inputBytes.Length];
            Array.Copy(saltBytes, saltedInputBytes, saltBytes.Length);
            Array.Copy(inputBytes, 0, saltedInputBytes, saltBytes.Length, inputBytes.Length);

            using var sha256 = SHA256.Create();
            byte[] hashedBytes = sha256.ComputeHash(saltedInputBytes);

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hashedBytes.Length; i++)
            {
                sb.Append(hashedBytes[i].ToString("x2"));
            }
            return sb.ToString();
        }
        public static string GetStringUnsaltedHash(this string input)
        {
            using SHA256 sha256Hash = SHA256.Create();
            byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(input));

            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < bytes.Length; i++)
            {
                builder.Append(bytes[i].ToString("x2"));
            }
            return builder.ToString();
        }
        public static string RemoveDiacritics(this string stIn)
        {
            string stFormD = stIn.Normalize(NormalizationForm.FormD);
            StringBuilder sb = new StringBuilder();

            for (int ich = 0; ich < stFormD.Length; ich++)
            {
                UnicodeCategory uc = CharUnicodeInfo.GetUnicodeCategory(stFormD[ich]);
                if (uc != UnicodeCategory.NonSpacingMark)
                {
                    sb.Append(stFormD[ich]);
                }
            }

            return (sb.ToString().Normalize(NormalizationForm.FormC));
        }

        public static string PrepareToHash(this string stIn)
        {
            return stIn.RemoveDiacritics().Trim().Replace(" ", string.Empty).ToUpperInvariant();
        }
    } 
}
