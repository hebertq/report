﻿using System.Data;
using OfficeOpenXml;
using OfficeOpenXml.Table;
using serfinsa.Domain.Common.Generic;

namespace serfinsa.Domain.Extensions
{
    public static class ExcelExtensions
    {
        public static string CreateExceltoDatatable(this DataTable data, string NombreHoja)
        {
            MemoryStream stream = new MemoryStream();
            using (var excelFile = new ExcelPackage(stream))
            {
                var worksheet = excelFile.Workbook.Worksheets.Add(NombreHoja);
                worksheet.Cells[1, 1].LoadFromDataTable(data, true);
                worksheet.Cells[worksheet.Dimension.Address].AutoFitColumns();
                excelFile.Save();
            }
            return Convert.ToBase64String(stream.ToByteArray());
        }

        public static byte[] ToByteArray(this Stream stream)
        {
            stream.Position = 0;
            byte[] buffer = new byte[stream.Length];
            for (int totalBytesCopied = 0; totalBytesCopied < stream.Length;)
                totalBytesCopied += stream.Read(buffer, totalBytesCopied, Convert.ToInt32(stream.Length) - totalBytesCopied);
            return buffer;
        }
        public static ExcelArray CreateExcel<T>(this List<T> table, string hoja)
        {
            ExcelArray libro = new ExcelArray();
            try
            {
                ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                using ExcelPackage pack = new ExcelPackage();

                ExcelWorksheet ws = pack.Workbook.Worksheets.Add(hoja);
                ws.Cells["A1"].LoadFromCollection(table, true, TableStyles.Light2);
                ws.Cells[ws.Dimension.Address].AutoFitColumns();

                libro.Data = pack.GetAsByteArray();
                libro.Nombre = hoja;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return libro;
        }

        public static string CreateExcel(this List<ExcelArray> table)
        {
            string buffer = "";
            try
            {
                ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                using ExcelPackage pack = new ExcelPackage();

                foreach (var item in table)
                {
                    using (MemoryStream memStream = new MemoryStream(item.Data!))
                    {
                        using ExcelPackage hija = new ExcelPackage();
                        hija.Load(memStream);
                        pack.Workbook.Worksheets.Add(item.Nombre, hija.Workbook.Worksheets[item.Nombre]);
                    }
                }

                buffer = Convert.ToBase64String(pack.GetAsByteArray());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return buffer;
        }
    }
}
