﻿using Newtonsoft.Json.Serialization;
using Newtonsoft.Json;

namespace serfinsa.Domain.Extensions
{
    public static class JsonSerializerExtensions
    {
        private static readonly DefaultContractResolver _contractResolverCamelCase = new DefaultContractResolver
        {
            NamingStrategy = new CamelCaseNamingStrategy()
        };

        private static readonly JsonSerializerSettings _jsonSerializerSettingsCamelCase = new JsonSerializerSettings
        {
            ContractResolver = _contractResolverCamelCase,
            Formatting = Formatting.Indented
        };

        private static readonly DefaultContractResolver _contractResolverSnakeCase = new DefaultContractResolver
        {
            NamingStrategy = new SnakeCaseNamingStrategy() { OverrideSpecifiedNames = false }
        };

        private static readonly JsonSerializerSettings _jsonSerializerSettingsSnakeCase = new JsonSerializerSettings
        {
            ContractResolver = _contractResolverSnakeCase,
            Formatting = Formatting.Indented
        };
        public static string SerializeWithCamelCase<T>(this T data)
        {
            return JsonConvert.SerializeObject(data, _jsonSerializerSettingsCamelCase);
        }
        public static T DeserializeFromCamelCase<T>(this string json)
        {
            return JsonConvert.DeserializeObject<T>(json, _jsonSerializerSettingsCamelCase)!;
        }
        public static string SerializeWithSnakeCase<T>(this T data)
        {
            return JsonConvert.SerializeObject(data, _jsonSerializerSettingsSnakeCase);
        }
        public static T DeserializeFromSnakeCase<T>(this string json)
        {
            return JsonConvert.DeserializeObject<T>(json, _jsonSerializerSettingsSnakeCase)!;
        }
    }
}

