﻿using serfinsa.Domain.Common.Generic;
using System.Xml.Serialization;
using System.Xml;
using serfinsa.Domain.Constant;

namespace serfinsa.Domain.Extensions
{
    public static class XmlExtensions
    {
        public static string ToXmlStringExtend<T>(this T o, string classname,string namespaces, bool addNamespaces = true) where T : new()
        {
            string response = string.Empty;
            var xmlDoc = SerializeToXmlDocument(o, namespaces, addNamespaces);
            using (var stringWriter = new StringWriter())
            using (var xmlTextWriter = XmlWriter.Create(stringWriter))
            {
                xmlDoc.WriteTo(xmlTextWriter);
                xmlTextWriter.Flush();
                response = stringWriter.GetStringBuilder().ToString().Replace("BodyModel", classname);
            }

            return response.Replace("_x003A_", ":").Replace($"<{classname}", $"<{classname} xmlns=\"{namespaces}/\"");
        }
        public static XmlDocument SerializeToXmlDocument<XmlEntity>(XmlEntity o, string namespaces, bool addNamespaces = true) where XmlEntity : new()
        {
            XmlDocument xdoc;          
            var wrapper = new Envelope<XmlEntity>();
            wrapper.XmlObject.Model = o;

            XmlSerializer xs = new XmlSerializer(wrapper.GetType());
            XmlSerializerNamespaces ns = new();
            using (MemoryStream ms = new MemoryStream())
            {
                if (!addNamespaces)
                {
                    ns.Add(string.Empty, string.Empty);
                    xs.Serialize(ms, wrapper, ns);
                }
                else
                {
                    ns.Add("soap", SoapConstants.Soap);
                    ns.Add("xsd", SoapConstants.Xsd);
                    ns.Add("xsi", SoapConstants.Xsi);
                    xs.Serialize(ms, wrapper,ns);
                }
                xdoc = new XmlDocument();
                ms.Position = 0;
                xdoc.Load(ms);
            }

            return xdoc;
        }
        public static T DeserializeInnerSoapObject<T>(string soapResponse, string namespacedata)
        {
            XmlDocument xmlDocument = new();
            xmlDocument.LoadXml(soapResponse);

            var soapBody = xmlDocument.GetElementsByTagName("Body", SoapConstants.Soap)[0]
                ?? throw new ArgumentException("The response content is not a valid soap message");

            string innerObject = soapBody.InnerXml;

            if (!string.IsNullOrEmpty(innerObject))
                innerObject = innerObject.Replace($" xmlns=\"{namespacedata}/\"", "");

            if (typeof(T) == typeof(string))
                return (T)(object)innerObject;

            var typeData = typeof(T);
            XmlSerializer deserializer = new XmlSerializer(typeData);

            using TextReader reader = new StringReader(innerObject);
            return (T)deserializer.Deserialize(reader)!;
        }

        /// <summary>
        /// Parse an object to XML string
        /// </summary>
        /// <typeparam name="T">Object</typeparam>
        /// <param name="o">Object</param>
        /// <returns></returns>
        public static string ToXmlString<T>(this T o, string namespaces = "", string namespacePrefix = "", bool addNamespaces = true) where T : new()
        {
            string retVal;
            using (var ms = new MemoryStream())
            {
                XmlSerializerNamespaces ns = new();
                var xs = new XmlSerializer(typeof(T));

                if (!addNamespaces)
                {
                    ns.Add(string.Empty, string.Empty);
                    xs.Serialize(ms, o, ns);
                }
                else
                {
                    if (string.IsNullOrEmpty(namespaces))
                    {
                        xs.Serialize(ms, o);
                    }
                    else
                    {
                        ns.Add(namespacePrefix, namespaces);
                        xs.Serialize(ms, o, ns);
                    }
                }

                ms.Flush();
                ms.Position = 0;
                var sr = new StreamReader(ms);
                retVal = sr.ReadToEnd();
            }
            return retVal;
        }
    }
}
