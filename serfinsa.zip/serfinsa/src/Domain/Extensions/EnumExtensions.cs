﻿using System.ComponentModel;

namespace serfinsa.Domain.Extensions
{
    public static class EnumExtensions
    {
        /// <summary>
        /// Gets a enum <c>Description</c> attribute (using DataAnnotations)
        /// </summary>
        /// <typeparam name="TValue">Enum type</typeparam>
        /// <param name="value">Enum instance</param>
        /// <returns>
        /// The description attribute of the corresponding enum value, <c>null</c> if not found
        /// </returns>
        public static string? GetDescription<T>(this T value) where T : Enum
        {
            if (!typeof(T).IsEnum)
                return null;

            var description = value.ToString();
            var fieldInfo = value.GetType().GetField(value.ToString());

            if (fieldInfo != null)
            {
                var attrs = fieldInfo.GetCustomAttributes(typeof(DescriptionAttribute), true);
                if (attrs != null && attrs.Length > 0)
                {
                    description = ((DescriptionAttribute)attrs[0]).Description;
                }
            }

            return description;
        }

        /// <summary>
        /// Parses a string value into its enum value by variable name
        /// </summary>
        /// <typeparam name="T">enum Type</typeparam>
        /// <param name="value">this string value</param>
        /// <returns>The parsed enum value, default if not found</returns>
        public static T ParseEnum<T>(this string value) where T : Enum
        {
            return (T)Enum.Parse(typeof(T), value, true);
        }

        /// <summary>
        /// Gets a enum value by its description string 
        /// </summary>
        /// <typeparam name="T">The enum type desired</typeparam>
        /// <param name="description">The string description to get the value</param>
        /// <returns>The corresponding enum</returns>
        public static T? GetValueFromDescription<T>(this string description) where T : Enum
        {
            foreach (var field in typeof(T).GetFields())
            {
                if (Attribute.GetCustomAttribute(field,
                typeof(DescriptionAttribute)) is DescriptionAttribute attribute)
                {
                    if (attribute.Description == description)
                        return (T)field.GetValue(null)!;
                }
                else
                {
                    if (field.Name == description)
                        return (T)field.GetValue(null)!;
                }
            }

            // if not found
            return default;
        }
        /// <summary>
        /// Enumerar datos
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="obj"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        public static bool In<T>(this T obj, params T[] args)
        {
            return args.Contains(obj);
        }
    }
}
