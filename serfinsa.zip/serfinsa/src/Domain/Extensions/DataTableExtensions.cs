﻿using System.ComponentModel;
using System.Data;
using System.Reflection;
using serfinsa.Domain.Common.Generic;

namespace serfinsa.Domain.Extensions
{
    public static class DataTableExtensions
    {
        public delegate T CreateObjectDelegate<T>();

        public static DataTable? ConvertTo<T>(this List<T> list, string nombre)
        {
            DataTable table = CreateTable<T>(nombre);
            Type entityType = typeof(T);
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(entityType);
            object? value = null;
            DateTime? dte = default(DateTime);

            foreach (T item in list)
            {
                DataRow row = table.NewRow();
                foreach (PropertyDescriptor prop in properties)
                {
                    TypeCode typeCode = Type.GetTypeCode(prop.PropertyType);
                    string Name = prop.Name;

                    try
                    {
                        if (prop.PropertyType.BaseType!.Name == "Enum")
                            value = Convert.ToInt32(prop.GetValue(item));
                        else
                        {
                            switch (typeCode)
                            {
                                case TypeCode.Int32:
                                    value = Convert.ToInt32(prop.GetValue(item));
                                    break;
                                case TypeCode.Decimal:
                                    value = Convert.ToDecimal(prop.GetValue(item));
                                    break;
                                case TypeCode.Boolean:
                                    value = Convert.ToBoolean(prop.GetValue(item));
                                    break;
                                case TypeCode.DateTime:
                                    value = Convert.ToDateTime(prop.GetValue(item));
                                    break;
                                default:
                                    value = prop.GetValue(item)!;
                                    break;
                            }
                        }

                        if (value != null)
                        {
                            row[prop.Name] = value;
                        }
                        else
                        {
                            row[prop.Name] = DBNull.Value;
                        }
                    }
                    catch (Exception ex)
                    {
                        string msj = $"Error de conversión de {Name} de valor {prop.GetValue(item)}";
                        throw new Exception(msj, ex)!;
                    }
                }
                table.Rows.Add(row);
            }
            return table;
        }
        public static List<T>? ConvertTo<T>(this List<DataRow> rows,CreateObjectDelegate<T> del)
        {
            List<T>? list = null;
            if (rows != null)
            {
                list = new List<T>();
                foreach (DataRow row in rows)
                {
                    T item = CreateItem<T>(row, del);
                    list.Add(item);
                }
            }
            return list;
        }
        public static List<T>? ConvertTo<T>(this List<DataRow> rows)
        {
            List<T>? list = null;
            if (rows != null)
            {
                list = new List<T>();
                foreach (DataRow row in rows)
                {
                    T item = CreateItem<T>(row);
                    list.Add(item);
                }
            }
            return list;
        }
        public static List<T>? ConvertTo<T>(this DataRow[] rows)
        {
            List<T>? list = null;
            if (rows != null)
            {
                list = new List<T>();
                foreach (DataRow row in rows)
                {
                    T item = CreateItem<T>(row);
                    list.Add(item);
                }
            }
            return list;
        }
        public static List<T>? ConvertTo<T>(List<DataRow> rows, string sortString)
        {
            List<T>? list = null;
            if (rows != null)
            {
                list = new List<T>();
                foreach (DataRow row in rows)
                {
                    T item = CreateItem<T>(row);
                    list.Add(item);
                }
                GenericSorter<T> sorter = new GenericSorter<T>(sortString);
                list.Sort(sorter);
            }
            return list;
        }
        public static List<T>? ConvertTo<T>(DataTable dt, string sortString)
        {
            if (dt == null)
            {
                return null;
            }
            List<DataRow> rows = new List<DataRow>();
            foreach (DataRow row in dt.Rows)
            {
                rows.Add(row);
            }
            return ConvertTo<T>(rows, sortString);
        }
        public static List<T> ConvertTo<T>(DataTable dt)
        {
            return ConvertTo<T>(dt.Select())!;
        }     
        

        public static List<T>? ConvertTo<T>(DataTable dt, CreateObjectDelegate<T> del)
        {
            if (dt == null)
            {
                return null;
            }
            List<DataRow> rows = new List<DataRow>();
            foreach (DataRow row in dt.Rows)
            {
                rows.Add(row);
            }
            return ConvertTo<T>(rows, del);
        }
        public static T CreateItem<T>(DataRow dr, CreateObjectDelegate<T> del)
        {
            var obj = default(T);

            if (dr is not null)
            {
                if (del is not null)
                {
                    obj = del.Invoke();
                }
                else
                {
                    obj = Activator.CreateInstance<T>();
                }
                if (obj is not null)
                {
                    foreach (DataColumn column in dr.Table.Columns)
                    {
                        PropertyInfo prop = obj.GetType().GetProperty(column.ColumnName)!;
                        if (prop is not null)
                        {
                            if (!object.ReferenceEquals(dr[column.ColumnName], DBNull.Value))
                            {
                                prop.SetValue(obj, dr[column.ColumnName], null);
                            }
                            else
                            {
                                prop.SetValue(obj, null, null);
                            }
                        }
                    }
                }
            }
            return obj!;
        }
        public static T CreateItem<T>(DataRow dr)
        {
            var obj = default(T);

            if (dr is not null)
            {
                obj = Activator.CreateInstance<T>();
                if (obj is not null)
                {
                    foreach (DataColumn column in dr.Table.Columns)
                    {
                        PropertyInfo prop = obj.GetType().GetProperty(column.ColumnName)!;
                        if (prop != null)
                        {
                            if (!object.ReferenceEquals(dr[column.ColumnName], DBNull.Value))
                            {
                                prop.SetValue(obj, dr[column.ColumnName], null);
                            }
                            else
                            {
                                prop.SetValue(obj, null, null);
                            }
                        }
                    }
                }
            }
            return obj!;
        }
        public static DataTable CreateTable<T>(string nombre)
        {
            Type entityType = typeof(T);
            DataTable dt = new DataTable(nombre);
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(entityType);
            if (properties != null)
            {
                foreach (PropertyDescriptor prop in properties)
                {
                    DataColumn colString = new DataColumn(prop.Name);
                    if (prop.PropertyType.FullName != "System.String")
                    {
                        TypeCode typeCode = Type.GetTypeCode(prop.PropertyType);
                        switch (typeCode)
                        {
                            case TypeCode.Boolean:
                                colString.DataType = System.Type.GetType("System.Boolean");
                                break;
                            case TypeCode.Object:
                                if (prop.PropertyType.FullName!.Contains("DateTime"))
                                {
                                    colString.DataType = System.Type.GetType("System.DateTime");
                                }
                                else if (prop.PropertyType.FullName.Contains("Decimal"))
                                {
                                    colString.DataType = System.Type.GetType("System.Decimal");
                                }
                                else if (prop.PropertyType.FullName.Contains("Int"))
                                {
                                    colString.DataType = System.Type.GetType("System.Int");
                                }
                                else if (prop.PropertyType.FullName.Contains("Boolean"))
                                {
                                    colString.DataType = System.Type.GetType("System.Boolean");
                                }
                                break;
                        }
                    }

                    dt.Columns.Add(colString);
                }
            }
            return dt;
        }
    }
}
