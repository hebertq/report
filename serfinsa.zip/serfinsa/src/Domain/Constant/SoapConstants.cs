﻿namespace serfinsa.Domain.Constant
{
    public static class SoapConstants
    {
        public const string Soap = "http://schemas.xmlsoap.org/soap/envelope/";
        public const string Xsd = "http://www.w3.org/2001/XMLSchema";
        public const string Xsi = "http://www.w3.org/2001/XMLSchema-instance";       
    }
}
