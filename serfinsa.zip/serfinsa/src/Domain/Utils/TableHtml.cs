﻿namespace serfinsa.Domain.Utils
{
    public static class TableHtml
    {
        public static string ToHtmlTable<T>(this List<T> listOfClassObjects, string titulo)
        {
            var ret = string.Empty;
            var response = listOfClassObjects == null || !listOfClassObjects.Any()
                ? ret
                : "<table cellspacing=\"0\" cellpadding=\"0\" border=\"1\">" +
                  listOfClassObjects.FirstOrDefault()!.GetType().GetProperties().Select(p => p.Name).ToList().ToColumnHeaders() +
                  listOfClassObjects.Aggregate(ret, (current, t) => current + t.ToHtmlTableRow()) +
                  "</table>";

            return "<h2>" + titulo + "</h2></hr>" + response;
        }

        private static string ToColumnHeaders<T>(this List<T> listOfProperties)
        {
            var ret = string.Empty;
            return listOfProperties == null || !listOfProperties.Any()
                ? ret
                : "<tr>" +
                  listOfProperties.Aggregate(ret,
                      (current, propValue) =>
                          current +
                          ("<th align = \"center\" valign=\"top\"style='font-size: 11pt; font-weight: bold;min-width:100%;background:linear-gradient(to bottom,#003815 0%,#008559 100%);color:#FFFFFF;padding:5px;'>" +
                           (Convert.ToString(propValue)!.Length <= 100
                               ? Convert.ToString(propValue)!
                               : Convert.ToString(propValue)!.Substring(0, 100)) + "</th>")) +
                  "</tr>";
        }

        private static string? ToHtmlTableRow<T>(this T classObject)
        {
            var ret = string.Empty;
            return classObject == null
                ? ret
                : "<tr>" +
                  classObject.GetType()
                      .GetProperties()
                      .Aggregate(ret,
                          (current, prop) =>
                              current + ("<td align = \"left\" style='font-size: 10pt; font-weight: normal;padding-left:5px;padding-left:5px;padding-right:5px;'>" +
                                         (Convert.ToString(prop.GetValue(classObject, null))!.Length <= 100
                                             ? Convert.ToString(prop.GetValue(classObject, null))!
                                             : Convert.ToString(prop.GetValue(classObject, null))!.Substring(0, 100)) +
                                         "</td>")) + "</tr>";
        }
    }
}
