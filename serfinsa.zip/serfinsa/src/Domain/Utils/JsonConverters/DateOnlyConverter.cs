﻿using System.Globalization;
using System.Text.Json.Serialization;
using System.Text.Json;

namespace serfinsa.Domain.Utils.JsonConverters
{
    public class DateOnlyConverter : JsonConverter<DateOnly>
    {
        private readonly string _dateFormat;

        public DateOnlyConverter(string dateFormat)
        {
            _dateFormat = dateFormat;
        }

        public override DateOnly Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            if (reader.GetString() == null) throw new ArgumentNullException(nameof(reader));

            return DateOnly.ParseExact(reader.GetString()!, _dateFormat, CultureInfo.InvariantCulture);
        }

        public override void Write(Utf8JsonWriter writer, DateOnly value, JsonSerializerOptions options)
        {
            writer.WriteStringValue(value.ToString(_dateFormat));
        }
    }
    public class DateOnlyConverterFactory : JsonConverterFactory
    {
        public override bool CanConvert(Type typeToConvert)
        {
            return typeToConvert == typeof(DateOnly);
        }

        public override JsonConverter CreateConverter(Type typeToConvert, JsonSerializerOptions options)
        {
            return new DateOnlyConverter("yyyy-MM-dd");
        }
    }
}

