﻿using System.Xml.Serialization;

namespace serfinsa.Domain.Common.Generic
{
    [XmlRoot("soap:Envelope")]
    public class Envelope<TObject> where TObject : new()
    {
        [XmlElement(ElementName = "soap:Body")]
        public BodyXML<TObject> XmlObject { get; set; } = new();
    }
}
