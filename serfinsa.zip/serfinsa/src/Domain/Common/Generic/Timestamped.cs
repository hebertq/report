﻿namespace serfinsa.Domain.Common.Generic
{
    public abstract class Timestamped
    {
        public DateTime Created { get; set; } = DateTime.UtcNow;
        public DateTime LastUpdate { get; set; } = DateTime.UtcNow;
        public int? CompanyId { get; set; } = 1;
    }
}
