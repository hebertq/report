﻿
namespace serfinsa.Domain.Common.Generic
{
    public class ErrorInfoLog
    {
        public string Key { set; get; }
        public object Value { set; get; }
    }
}
