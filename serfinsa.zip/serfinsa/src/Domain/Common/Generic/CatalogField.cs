﻿namespace serfinsa.Domain.Common.Generic
{
    public class CatalogField
    {
        public long? Id { get; set; }
        public string? Code { get; set; }
        public string? Description { get; set; }

        public CatalogField(string id,string code, string description)
        {
            Id = long.Parse(id);
            Code = code;
            Description = description;
        }
        public CatalogField()
        {

        }
    }

    public static class CatalogValuesHelper
    {
        public static string ToEntryString(this CatalogField entry)
        {
            return $"CAT:{entry.Id}#{entry.Code}#{entry.Description}";
        }

        public static CatalogField? FromEntryString(string entryString)
        {
            if (entryString.Split(':').Length != 2) return null;

            string[]? data = entryString.Split(':')[1]?.Split("#");

            if (data == null || data.Length != 2) return null;

            return new CatalogField(data[0], data[1], data[2]);
        }
    }
}
