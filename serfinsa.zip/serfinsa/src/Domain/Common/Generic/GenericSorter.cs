﻿using System.Collections;
using System.Reflection;
using serfinsa.Domain.Enums;

namespace serfinsa.Domain.Common.Generic
{
    /// <summary>
    /// Sorts a generic collection of some object
    ///
    /// Example:
    ///     Dim MyList As List(Of MyClassType) = 'Populate the list somehow
    ///     Dim Sorter As New Sorter(Of MyClassType)    '''     Sorter.SortString = "Field1 DESC, Field2"
    ///     MyList.Sort(Sorter) 'After this call, the list is sorted
    /// </summary>
    public class GenericSorter<T> : IComparer<T>
    {

        private string _sort;
        /// <summary>
        /// Instantiate the class.
        /// </summary>
        public GenericSorter()
        {
        }
        /// <summary>
        /// Instantiate the class, setting the sort string.
        ///
        /// Example: "LastName DESC, FirstName"
        /// </summary>
        public GenericSorter(string SortString)
        {
            _sort = SortString;
        }
        /// <summary>
        /// The sort string used to perform the sort. Can sort on multiple fields.
        /// Use the property names of the class and basic SQL Syntax.
        ///
        /// Example: "LastName DESC, FirstName"
        /// </summary>
        public string SortString
        {
            get
            {
                if (_sort != null)
                {
                    return _sort.Trim();
                }
                return null;
            }
            set { _sort = value; }
        }
        /// <summary>
        /// This is an implementation of IComparer(Of T).Compare
        /// Can sort on multiple fields, or just one.
        /// </summary>
        public int Compare(T x, T y)
        {
            if (!string.IsNullOrEmpty(this.SortString))
            {
                const string err = "The property \"{0}\" does not exist in type \"{1}\"";
                Type type = typeof(T);
                Comparer comp = Comparer.DefaultInvariant;
                PropertyInfo info = null;
                foreach (string ex in this.SortString.Split(','))
                {
                    SortOrderEnum dir = SortOrderEnum.Ascending;
                    string field = null;
                    string expr = string.Empty;
                    expr = ex.Trim();
                    if (expr.EndsWith(" DESC"))
                    {
                        field = expr.Replace(" DESC", string.Empty).Trim();
                        dir = SortOrderEnum.Descending;
                    }
                    else
                    {
                        field = expr.Replace(" ASC", string.Empty).Trim();
                    }
                    info = type.GetProperty(field)!;
                    if (info == null)
                    {
                        throw new MissingFieldException(string.Format(err, field, type.ToString()));
                    }
                    else
                    {
                        int Result = comp.Compare(info.GetValue(x, null), info.GetValue(y, null));
                        if (Result != 0)
                        {
                            if (dir == SortOrderEnum.Descending)
                            {
                                return Result * -1;
                            }
                            else
                            {
                                return Result;
                            }
                        }
                    }
                }
            }
            return 0;
        }
    }
}
