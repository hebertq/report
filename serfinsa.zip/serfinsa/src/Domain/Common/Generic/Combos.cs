﻿namespace serfinsa.Domain.Common.Generic
{
    public class Combos
    {
        public int id { set; get; } = 1;
        public string nombre { set; get; } = string.Empty;
    }
}
