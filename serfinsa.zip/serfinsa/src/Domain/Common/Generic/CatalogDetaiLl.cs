﻿namespace serfinsa.Domain.Common.Generic
{
    public class CatalogDetaiLl
    {
        public string? CatalogType { get; set; }
        public string? Description { get; set; }
        public int? Id { get; set; }
        public string? CoreCode { get; set; }
    }
}
