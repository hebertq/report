﻿using System.Xml.Serialization;

namespace serfinsa.Domain.Common.Generic
{
    public class BodyXML<TModel> where TModel : new()
    {
        [XmlElement(ElementName = "BodyModel")]
        public TModel Model { get; set;} = new();
    }    
}
