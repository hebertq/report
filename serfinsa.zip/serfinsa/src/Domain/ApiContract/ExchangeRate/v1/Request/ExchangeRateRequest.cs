﻿namespace serfinsa.Domain.ApiContract.ExchangeRate.v1.Request
{
    public class ExchangeRateRequest
    {
        public int Year { get; set; }
        public int Month { get; set; }
        public int Day { get; set; }
    }
}
