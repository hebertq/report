﻿using serfinsa.Domain.ApiContract.ExchangeRate.v1.Request;

namespace serfinsa.Domain.ApiContract.ExchangeRate.v1.Response
{
    public class ExchangeRateResponse: ExchangeRateRequest
    {
        public double Rate { get; set; }
    }
}
