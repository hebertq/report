﻿using System.ComponentModel.DataAnnotations.Schema;
using serfinsa.Domain.Common.Generic;

namespace serfinsa.Domain.Entities.People
{
    public class Profile : Timestamped
    {
        public int ProfileId { get; set; } = 0;

        [Column(TypeName = "jsonb")]
        public CatalogField? ResidenceCountry { get; set; }

        [Column(TypeName = "jsonb")]
        public Spouse? Spouse { get; set; }

        [Column(TypeName = "jsonb")]
        public CatalogField? Title { get; set; }

        [Column(TypeName = "jsonb")]
        public CatalogField? Occupation { get; set; }

        [Column(TypeName = "jsonb")]
        public CatalogField? EconomicActivity { get; set; }

        [Column(TypeName = "jsonb")]
        public PublicRelatedInformation? PublicRelated { get; set; }

        [Column(TypeName = "jsonb")]
        public EconomicDependentInformation? EconomicDependent { get; set; }

        [Column(TypeName = "jsonb")]
        public List<Reference>? References { get; set; }
        public long? GreenCard { get; set; }        

        [Column(TypeName = "jsonb")]
        public JobInformation? jobDetail { get; set; }

        [Column(TypeName = "jsonb")]
        public CatalogField? MaritalStatus { get; set; }     
        public int? NumberOfDependants { get; set; }
        public CatalogField? Region { get; set; }
        public string? Address { get; set; }
        public long? CellPhone { get; set; }
        public long? HomePhone { get; set; }
        public string? Email { get; set; }
        public List<ProfileDetail>? Detail { get; set; } 
    }
}
