﻿namespace serfinsa.Domain.Entities.People
{
    public class Identification
    {
        public int PersonId { get; set; } = 0;
        public string? CountryOfIssuance { get; set; }
        public string? IdentificationType { get; set; }
        public bool IsAvailable { get; set; } = false;
        public string? IdentificationNumber { get; set; }
        public DateOnly? IssueDate { get; set; }
        public DateOnly? ExpirationDate { get; set; }
        public string DocumentNumberHash
        { get { return SkKeyBuilder(CountryOfIssuance!, IdentificationType!, IdentificationNumber!); } }
        public static string SkKeyBuilder(string country, string identificationType, string identificationNumber) => $"I:{country}#{identificationType}#{identificationNumber}";
    }
}
