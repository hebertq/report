﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace serfinsa.Domain.Entities.People.Database
{
    public class ProfileDb:Profile
    {

    }
}
