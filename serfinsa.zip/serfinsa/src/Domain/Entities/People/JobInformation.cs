﻿namespace serfinsa.Domain.Entities.People
{
    /// <summary>
    /// Person job information object
    /// </summary>
    public class JobInformation : JobInformationBase
    {

        /// <summary>
        /// Employer number
        /// </summary>
        public long? EmployerNumber { get; set; }

        /// <summary>
        /// Work email.
        /// </summary>
        public string? WorkEmail { get; set; } = null!;

        /// <summary>
        /// Work time year
        /// </summary>
        public int? WorkTimeYears { get; set; }

        /// <summary>
        /// Business activity code
        /// </summary>
        public string? BusinessActivityCode { get; set; }

        /// <summary>
        /// Monthly income
        /// </summary>
        public double? OtherMonthlyIncome { get; set; }

        /// <summary>
        /// Work address
        /// </summary>
        public string? SecondWorkAddress { get; set; }

        /// <summary>
        /// Has Other Income
        /// </summary>
        public bool? HasOtherIncome { get; set; }

        /// <summary>
        /// Group code economic
        /// </summary>
        public string? GroupCodeEconomic { get; set; }

        /// <summary>
        /// Income currency
        /// </summary>
        public string? IncomeCurrency { get; set; }
    }

    public class JobInformationBase
    {
        /// <summary>
        /// Person's work place.
        /// </summary>
        public string? WorkPlace { get; set; }

        /// <summary>
        /// Person's work address.
        /// </summary>
        public string? WorkAddress { get; set; }

        /// <summary>
        /// Job position.
        /// </summary>
        public string? JobPosition { get; set; }

        /// <summary>
        /// Work geographic location code.
        /// </summary>
        public string? WorkGeographicLocationCode { get; set; }

        /// <summary>
        /// Work economic activity code.
        /// </summary>
        public string? WorkEconomicActivityCode { get; set; }

        /// <summary>
        /// Monthly income.
        /// </summary>
        public double? MonthlyIncome { get; set; }

        /// <summary>
        /// Monthly expenses
        /// </summary>
        public double? MonthlyExpenses { get; set; }

        /// <summary>
        /// Work phone.
        /// </summary>
        public long? WorkPhone { get; set; } = null!;

        /// <summary>
        /// Work start date
        /// </summary>
        public DateOnly? WorkStartDate { get; set; }

        /// <summary>
        /// Corporate position code
        /// </summary>
        public string? CorporatePositionCode { get; set; }

        /// <summary>
        /// Employer CIF
        /// </summary>
        public long? EmployerCif { get; set; }

        /// <summary>
        /// Is payroll employee
        /// </summary>
        public bool? IsPayrollEmployee { get; set; }
    }
}
