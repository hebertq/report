﻿
using serfinsa.Domain.Common.Generic;

namespace serfinsa.Domain.Entities.People
{
    public class Person : Timestamped
    {         
        public int PersonId { get; set; } = 0;
        public string? FirstName { get; set; }
        public string? SecondName { get; set; }
        public string? FirstLastName { get; set; }
        public string? SecondLastName { get; set; }
        public DateOnly BirthDate { get; set; }
        public CatalogField? BirthCountry { get; set; }
        public CatalogField? Gender { get; set; }        
        public Profile? Profile { get; set; }
        public List<Identification>? Identifications { get; set; } = [];
        public string? FullName { get; set; }

    }
}

