﻿using serfinsa.Domain.Common.Generic;
using serfinsa.Domain.Enums;

namespace serfinsa.Domain.Entities.People
{
    public class ProfileDetail : Timestamped
    {
        public int ProfileId { get; set; }
        public int? CustomerNumber { get; set; } = 0;
        public PersonProfileStatusEnum? ProfileType { get; set; }
        public List<Reference>? References { get; set; }
        public Identification? Document { get; set; }

        public string ProfileToHash
        {
            get => SkKeyBuilder(CompanyId, CustomerNumber == 0 ? "GES": CustomerNumber.ToString());
        }
        private static string SkKeyBuilder(int? companyId, string? customerNumber = "GES") => $"PRF:{companyId}#{customerNumber}";
    }
}
