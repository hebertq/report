﻿namespace serfinsa.Domain.Entities.People
{
    public class Reference: PersonBase
    {
        public double? MonthlyIncome { get; set; }
        public int? TimeToKnow { get; set; }
        public string? WorkAddress { get; set; }
        public long? WorkPhone { get; set; }
        public string? WorkPlace { get; set; }       
    }
}
