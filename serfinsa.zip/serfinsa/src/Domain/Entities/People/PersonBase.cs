﻿using serfinsa.Domain.Attributes;
using serfinsa.Domain.Common.Generic;
using serfinsa.Domain.Enums;
using serfinsa.Domain.Extensions;

namespace serfinsa.Domain.Entities.People
{
    public abstract class PersonBase: Timestamped
    {
        public int PersonId { get; set; } = 0;
        public string? FirstName { get; set; } 
        public string? SecondName { get; set; }
        public string? FirstLastName { get; set; } 
        public string? SecondLastName { get; set; }
        public DateOnly BirthDate { get; set; }

        /// <summary>
        /// Residence country code.
        /// </summary>
        [CatalogCode(CatalogTypeEnum.Country, "ResidenceCountry")]
        public string? BirthDateCountryCode { get; set; }
        [CatalogCode(CatalogTypeEnum.Gender)]
        public string? GenderCode { get; set; }
        public string FullName
        {
            get => BuildFullName(FirstName, SecondName, FirstLastName, SecondLastName);
        }
        public string NameToHash
        {
            get => PkKeyBuilder(FirstName!, SecondName, FirstLastName!, SecondLastName, BirthDate, BirthDateCountryCode!);
        }

        private static string BuildFullName(string? firstName, string? secondName, string? firstLastName, string? secondLastName)
        {
            return $"{firstName.AddSpaceIfNotNull()}{secondName.AddSpaceIfNotNull()}{firstLastName.AddSpaceIfNotNull()}{secondLastName.AddSpaceIfNotNull()}".Trim();
        }
        public static string PkKeyBuilder(string firstName, string? secondName, string firstLastName, string? secondLastName,
            DateOnly birthDate, string birthCountry) =>
            $"P:{BuildFullName(firstName, secondName, firstLastName, secondLastName).PrepareToHash()}#{birthDate:o}#{birthCountry.PrepareToHash()}".GetStringUnsaltedHash();
    }
}
