﻿namespace serfinsa.Domain.Entities.People
{
    public class EconomicDependentInformation: PersonBase
    {       
        /// <summary>
        /// Monthly income
        /// </summary>
        public double? MonthlyIncome { get; set; }

        /// <summary>
        /// Economic activity code
        /// </summary>
        public string? EconomicActivityCode { get; set; }

        /// <summary>
        /// Relation description
        /// </summary>
        public string? Relation { get; set; } = null!;
    }
}
