﻿namespace serfinsa.Domain.Entities.People
{
    public class Spouse : PersonBase
    {       
        public double? MonthlyIncome { get; set; }
        public string? WorkPlace { get; set; }
        public string? WorkAddress { get; set; }      
        public long? WorkPhone { get; set; }
        public string? WorkEmail { get; set; }
    }
}
