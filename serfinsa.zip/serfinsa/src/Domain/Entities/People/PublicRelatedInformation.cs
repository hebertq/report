﻿namespace serfinsa.Domain.Entities.People
{
    public class PublicRelatedInformation: PersonBase
    {
        /// <summary>
        /// Institution name
        /// </summary>
        public string? InstitutionName { get; set; }

        /// <summary>
        /// Public position
        /// </summary>
        public string? PublicPosition { get; set; }

        /// <summary>
        /// Period in years
        /// </summary>
        public string? PeriodYears { get; set; }

        /// <summary>
        /// Relationship type code
        /// </summary>
        public string? RelationshipTypeCode { get; set; }

    }
}
