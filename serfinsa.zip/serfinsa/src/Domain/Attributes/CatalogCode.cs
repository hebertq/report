﻿using serfinsa.Domain.Enums;

namespace serfinsa.Domain.Attributes
{
    /// <summary>
    /// Defines a Property as a catalog code for use with ICommonCatalogHelper
    /// </summary>
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
    public class CatalogCode : Attribute
    {
        public CatalogTypeEnum CatalogType { get; set; }
        public string TargetFieldName { get; set; }

        /// <summary>
        /// CTOR
        /// </summary>
        /// <param name="catalogType">CatalogType code</param>
        /// <param name="targetFieldName">Target entity field name, will take catalogtype if null</param>
        public CatalogCode(CatalogTypeEnum catalogType, string? targetFieldName = null)
        {
            CatalogType = catalogType;
            TargetFieldName = targetFieldName ?? catalogType.ToString();
        }
    }
}


