﻿using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using RestSharp.Authenticators;
using RestSharp;
using serfinsa.Domain.Common.Generic;
using serfinsa.Infrastructure.Http.Interfaces;
using Newtonsoft.Json;

namespace serfinsa.Infrastructure.Http.Rest
{
    /// <summary>
    /// Base RestApiService class for REST API services with injectable error handler
    /// </summary>
    public class RestApiService
    {
        private readonly RestClient _restClient;
        private readonly ILogger<RestApiService> _logger;
        private readonly IRestApiErrorHandler _errorHandler;

        // access to client options is allowed for inheriting classes
        protected readonly RestClientOptions _restClientOptions = new();

        public RestApiService(HttpClient httpClient, ILogger<RestApiService> logger, IRestApiErrorHandler restApiErrorHandler)
        {
            _restClient = new RestClient(httpClient, _restClientOptions);
            _logger = logger;
            _errorHandler = restApiErrorHandler;
        }

        protected void SetAuthenticator(IAuthenticator authenticator)
        {
            _restClient.Authenticator = authenticator;
        }

        protected void AddDefaultHeaders(Dictionary<string, string> values)
        {
            _restClient.AddDefaultHeaders(values);
        }

        public int Client { get; set; }

        /// <summary>
        /// Makes a GET request to any REST API with return expected
        /// </summary>
        /// <typeparam name="T">the expected return type (or response mapping class)</typeparam>
        /// <param name="request">the request object (with endpoint path)</param>
        /// <returns>
        /// The response result object, it may not succeed if validation business errors or integrity
        /// errors occur
        /// </returns>
        public async Task<Result<T>> GetRequest<T>(RestRequest request, [CallerMemberName] string callerMemberName = "")
        {
            var stopWatch = new Stopwatch();
            stopWatch.Start();
            LogPreRequest(request, callerMemberName);
            var response = await _restClient.ExecuteGetAsync<string>(request);
            stopWatch.Stop();
            // If response fails
            if (!response.IsSuccessful)
            {
                LogRequestFailed(request, response, stopWatch, callerMemberName);
                return _errorHandler.ValidateResponseError<T>(response, Client);
            }

            LogRequestSucceeded(request, response, stopWatch, callerMemberName);
            return new Result<T>(JsonConvert.DeserializeObject<T>(response.Data!)!, true, "", "");
        }

        /// <summary>
        /// Makes a POST request to any REST API with return expected
        /// </summary>
        /// <typeparam name="T">the expected return type (or response mapping class)</typeparam>
        /// <param name="request">the request object (with endpoint path) and the request body</param>
        /// <returns>
        /// The response result object, it may not succeed if validation business errors or integrity
        /// errors occur
        /// </returns>
        public async Task<Result<T>> PostRequest<T>(RestRequest request, [CallerMemberName] string callerMemberName = "")
        {
            var stopWatch = new Stopwatch();
            stopWatch.Start();
            LogPreRequest(request, callerMemberName);
            var response = await _restClient.ExecutePostAsync<string>(request);
            stopWatch.Stop();
            // If response fails
            if (!response.IsSuccessful)
            {
                LogRequestFailed(request, response, stopWatch, callerMemberName);
                return _errorHandler.ValidateResponseError<T>(response, Client);
            }

            LogRequestSucceeded(request, response, stopWatch, callerMemberName);
            return new Result<T>(JsonConvert.DeserializeObject<T>(response.Data!)!, true, "", "");
        }

        /// <summary>
        /// Makes a POST request to any REST API without return expected
        /// </summary>
        /// <param name="request">the request object (with endpoint path)</param>
        /// <returns>
        /// The response result object ( <c>string</c> type), it may not succeed if validation
        /// business errors or integrity errors occur
        /// </returns>
        public async Task<Result<string>> PostRequest(RestRequest request, [CallerMemberName] string callerMemberName = "")
        {
            var stopWatch = new Stopwatch();
            stopWatch.Start();
            LogPreRequest(request, callerMemberName);
            var response = await _restClient.ExecutePostAsync(request);
            stopWatch.Stop();
            // If response fails
            if (!response.IsSuccessful)
            {
                LogRequestFailed(request, response, stopWatch, callerMemberName);
                return _errorHandler.ValidateResponseError<string>(response, Client);
            }

            LogRequestSucceeded(request, response, stopWatch, callerMemberName);
            return new Result<string>("Success", true, "", "");
        }

        /// <summary>
        /// Makes a PUT request to any REST API with return expected
        /// </summary>
        /// <typeparam name="T">the expected return type (or response mapping class)</typeparam>
        /// <param name="request">the request object (with endpoint path) and the request body</param>
        /// <returns>
        /// The response result object, it may not succeed if validation business errors or integrity
        /// errors occur
        /// </returns>
        public async Task<Result<T>> PutRequest<T>(RestRequest request, [CallerMemberName] string callerMemberName = "")
        {
            var stopWatch = new Stopwatch();
            stopWatch.Start();
            LogPreRequest(request, callerMemberName);
            var response = await _restClient.ExecutePutAsync<string>(request);
            stopWatch.Stop();
            // If response fails
            if (!response.IsSuccessful)
            {
                LogRequestFailed(request, response, stopWatch, callerMemberName);
                return _errorHandler.ValidateResponseError<T>(response, Client);
            }

            LogRequestSucceeded(request, response, stopWatch, callerMemberName);
            return new Result<T>(JsonConvert.DeserializeObject<T>(response.Data!)!, true, "", "");
        }

        /// <summary>
        /// Makes a PUT request to any REST API without return expected
        /// </summary>
        /// <param name="request">the request object (with endpoint path)</param>
        /// <returns>
        /// The response result object ( <c>string</c> type), it may not succeed if validation
        /// business errors or integrity errors occur
        /// </returns>
        public async Task<Result<string>> PutRequest(RestRequest request, [CallerMemberName] string callerMemberName = "")
        {
            var stopWatch = new Stopwatch();
            stopWatch.Start();
            LogPreRequest(request, callerMemberName);
            var response = await _restClient.ExecutePutAsync(request);
            stopWatch.Stop();
            // If response fails
            if (!response.IsSuccessful)
            {
                LogRequestFailed(request, response, stopWatch, callerMemberName);
                return _errorHandler.ValidateResponseError<string>(response, Client);
            }

            LogRequestSucceeded(request, response, stopWatch, callerMemberName);
            return new Result<string>("Success", true, "", "");
        }

        /// <summary>
        /// Makes a PATCH request to any REST API with return expected
        /// </summary>
        /// <typeparam name="T">the expected return type (or response mapping class)</typeparam>
        /// <param name="request">the request object (with endpoint path) and the request body</param>
        /// <returns>
        /// The response result object, it may not succeed if validation business errors or integrity
        /// errors occur
        /// </returns>
        public async Task<Result<T>> PatchRequest<T>(RestRequest request, [CallerMemberName] string callerMemberName = "")
        {
            request.Method = Method.Patch;
            var stopWatch = new Stopwatch();
            stopWatch.Start();
            LogPreRequest(request, callerMemberName);
            var response = await _restClient.ExecuteAsync<string>(request);
            stopWatch.Stop();
            // If response fails
            if (!response.IsSuccessful)
            {
                LogRequestFailed(request, response, stopWatch, callerMemberName);
                return _errorHandler.ValidateResponseError<T>(response, Client);
            }

            LogRequestSucceeded(request, response, stopWatch, callerMemberName);
            return new Result<T>(JsonConvert.DeserializeObject<T>(response.Data!)!, true, "", "");
        }

        /// <summary>
        /// Makes a PATCH request to any REST API without return expected
        /// </summary>
        /// <param name="request">the request object (with endpoint path)</param>
        /// <returns>
        /// The response result object ( <c>string</c> type), it may not succeed if validation
        /// business errors or integrity errors occur
        /// </returns>
        public async Task<Result<string>> PatchRequest(RestRequest request, [CallerMemberName] string callerMemberName = "")
        {
            request.Method = Method.Patch;
            var stopWatch = new Stopwatch();
            stopWatch.Start();
            LogPreRequest(request, callerMemberName);
            var response = await _restClient.ExecuteAsync(request);
            stopWatch.Stop();
            // If response fails
            if (!response.IsSuccessful)
            {
                LogRequestFailed(request, response, stopWatch, callerMemberName);
                return _errorHandler.ValidateResponseError<string>(response, Client);
            }

            LogRequestSucceeded(request, response, stopWatch, callerMemberName);
            return new Result<string>("Success", true, "", "");
        }

        /// <summary>
        /// Makes a DELETE request to any REST API with return expected
        /// </summary>
        /// <typeparam name="T">the expected return type (or response mapping class)</typeparam>
        /// <param name="request">the request object (with endpoint path) and the request body</param>
        /// <returns>
        /// The response result object, it may not succeed if validation business errors or integrity
        /// errors occur
        /// </returns>
        public async Task<Result<T>> DeleteRequest<T>(RestRequest request, [CallerMemberName] string callerMemberName = "", JsonSerializerOptions options = null)
        {
            request.Method = Method.Delete;
            var stopWatch = new Stopwatch();
            stopWatch.Start();
            LogPreRequest(request, callerMemberName);
            var response = await _restClient.ExecuteAsync<string>(request);
            stopWatch.Stop();
            // If response fails
            if (!response.IsSuccessful)
            {
                LogRequestFailed(request, response, stopWatch, callerMemberName);
                return _errorHandler.ValidateResponseError<T>(response, Client);
            }
            LogRequestSucceeded(request, response, stopWatch, callerMemberName);
            return new Result<T>(JsonConvert.DeserializeObject<T>(response.Data!)!, true, "", "");
        }

        /// <summary>
        /// Makes a DELETE request to any REST API without return expected
        /// </summary>
        /// <param name="request">the request object (with endpoint path)</param>
        /// <returns>
        /// The response result object ( <c>string</c> type), it may not succeed if validation
        /// business errors or integrity errors occur
        /// </returns>
        public async Task<Result<string>> DeleteRequest(RestRequest request, [CallerMemberName] string callerMemberName = "")
        {
            request.Method = Method.Delete;
            var stopWatch = new Stopwatch();
            stopWatch.Start();
            LogPreRequest(request, callerMemberName);
            var response = await _restClient.ExecuteAsync(request);
            stopWatch.Stop();
            // If response fails
            if (!response.IsSuccessful)
            {
                LogRequestFailed(request, response, stopWatch, callerMemberName);
                return _errorHandler.ValidateResponseError<string>(response, Client);
            }
            LogRequestSucceeded(request, response, stopWatch, callerMemberName);
            return new Result<string>("Success", true, "", "");
        }

        /// <summary>
        /// Executes any RestRequest that expects a response
        /// </summary>
        /// <typeparam name="T">the expected return type (or response mapping class)</typeparam>
        /// <param name="request">the request object (with endpoint path) and the request body. Is required to provide the HTTP Method associated to the request</param>
        /// <returns>
        /// The response result object, it may not succeeded if validation business errors or integrity
        /// errors occur
        /// </returns>
        public async Task<Result<T>> ExecuteRequest<T>(RestRequest request, [CallerMemberName] string callerMemberName = "")
        {
            var stopWatch = new Stopwatch();
            stopWatch.Start();
            LogPreRequest(request, callerMemberName);
            var response = await _restClient.ExecuteAsync<string>(request);
            stopWatch.Stop();

            // If response fails
            if (!response.IsSuccessful)
            {
                LogRequestFailed(request, response, stopWatch, callerMemberName);
                return _errorHandler.ValidateResponseError<T>(response, Client);
            }
            LogRequestSucceeded(request, response, stopWatch, callerMemberName);
            return new Result<T>(JsonConvert.DeserializeObject<T>(response.Data!)!, true, "", "");
        }

        /// <summary>
        /// Executes any RestRequest without any return expected
        /// </summary>
        /// <param name="request">the request object (with endpoint path) and the request body. Is required to provide the HTTP Method associated to the request</param>
        /// <returns>
        /// Success if the request is OK, it may not succeeded if validation business errors or integrity
        /// errors occur
        /// </returns>
        public async Task<Result<string>> ExecuteRequest(RestRequest request, [CallerMemberName] string callerMemberName = "")
        {
            var stopWatch = new Stopwatch();
            stopWatch.Start();
            LogPreRequest(request, callerMemberName);
            var response = await _restClient.ExecuteAsync(request);
            stopWatch.Stop();

            // If response fails
            if (!response.IsSuccessful)
            {
                LogRequestFailed(request, response, stopWatch, callerMemberName);
                return _errorHandler.ValidateResponseError<string>(response, Client);
            }
            LogRequestSucceeded(request, response, stopWatch, callerMemberName);
            return new Result<string>("Success", true, "", "");
        }

        private void LogPreRequest(RestRequest request, string callerMemberName = "unknown")
        {
            _logger.LogInformation($"Inicia {request.Method} request {callerMemberName} en {(Client != 0 ? Client : "global")}. " +
                $"Url: {_restClient.BuildUri(request)}. " +
                $"Headers: {JsonConvert.SerializeObject(request.Parameters.Where(x => x.Type == ParameterType.HttpHeader).Concat(_restClient.DefaultParameters.Where(y => y.Type == ParameterType.HttpHeader)))}. " +
                $"Cuerpo: {JsonConvert.SerializeObject(request.Parameters.FirstOrDefault(x => x.Type == ParameterType.RequestBody) ?? null) ?? "n/a"}.");
        }

        private void LogRequestFailed(RestRequest request, RestResponse response, Stopwatch stopwatch, string callerMemberName = "unknown")
        {
            _logger.LogError($"El {request.Method} request {callerMemberName} en {(Client != 0 ? Client : "global")} ha fallado. Tiempo de respuesta: {stopwatch.ElapsedMilliseconds / 1000f}s. " +
                $"Status: {response.StatusCode}. Respuesta: {response.Content}");
        }

        private void LogRequestSucceeded(RestRequest request, RestResponse response, Stopwatch stopwatch, string callerMemberName = "unknown")
        {
            _logger.LogInformation($"El {request.Method} request {callerMemberName} en {(Client != 0 ? Client : "global")} ha sido exitoso. Tiempo de respuesta: {stopwatch.ElapsedMilliseconds / 1000f}s. " +
                $"Status: {response.StatusCode}. Respuesta: {response.Content}");
        }
    }
}
