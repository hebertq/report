﻿using System.Text.Json;
using RestSharp;
using serfinsa.Domain.Common.Generic;

namespace serfinsa.Infrastructure.Http.Interfaces
{
    public interface IRestApiErrorHandler
    {
        Result<T> ValidateResponseError<T>(RestResponse response, int client, JsonSerializerOptions? jsonSerializerOptions = null);
    }
}
