﻿using serfinsa.Application.Common.Interfaces;
using serfinsa.Infrastructure.Services;
using Microsoft.Extensions.Configuration;
using serfinsa.Infrastructure.Common.Struct;
using serfinsa.Infrastructure.Common.Configurations;
using serfinsa.Infrastructure.Common.Interface;
using serfinsa.Infrastructure.SoapClient.Interfaces;
using serfinsa.Infrastructure.SoapClient;
using SoapHttpClient;
using serfinsa.Infrastructure.Services.People;
using serfinsa.Application.Common.Interfaces.People;
using serfinsa.Application.Common.Interfaces.Intranet;
using serfinsa.Infrastructure.Services.Intranet;

namespace Microsoft.Extensions.DependencyInjection
{
    public static class ConfigureServices
    {
        public static IServiceCollection AddInfrastructureServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSingleton<NpgContext>();           
            services.Configure<ContexOptions>(configuration.GetSection("ContexDb"));
            services.Configure<RetryAndWaitPolicyOptions>(configuration.GetSection("RetryAndWaitPolicy"));

            services.AddSingleton<IDapper,Dapperr>();            
            services.AddTransient<ISoapClient, SoapClient>();
            services.AddTransient<ISoapClientService, SoapClientService>();

            services.AddTransient<ITodoService, TodoService>();
            services.AddTransient<IAdminService, AdminService>();
            services.AddTransient<IExchangeRateService, ExchangeRateService>();
            services.AddTransient<IPersonRepository, PersonRepository>();
            services.AddTransient<IIdentificationRepository, IdentificationRepository>();
            services.AddTransient<IProfileRepository, ProfileRepository>();
            services.AddTransient<IIntranetCatalogService, IntranetCatalogService>();
            


            return services;
        }
    }
}
