﻿using System.Data;
using serfinsa.Infrastructure.Common.Interface;
using serfinsa.Domain.Common.Generic;
using Microsoft.Extensions.Options;
using serfinsa.Infrastructure.Common.Configurations;
using serfinsa.Infrastructure.Common.Struct;
using serfinsa.Application.Common.Interfaces;
using serfinsa.Domain.Enums;

namespace serfinsa.Infrastructure.Services
{
    public class AdminService: BaseService, IAdminService
    {
        public AdminService(IDapper dapper, IOptions<ContexOptions> configuration):base(dapper, configuration, InfoContexEnum.Odoo){}

        public async Task<List<Combos>> GetAllOperaciones()
        {
            return await _dapper.GetAllAsync<Combos>("select * from public.getoperaciones()", null, CommandType.Text);
        }
    }
}
