﻿using System.Data;
using Microsoft.Extensions.Options;
using serfinsa.Application.Common.Interfaces.People;
using serfinsa.Domain.Entities.People;
using serfinsa.Domain.Enums;
using serfinsa.Infrastructure.Common.Configurations;
using serfinsa.Infrastructure.Common.Interface;
using serfinsa.Infrastructure.Common.Struct;

namespace serfinsa.Infrastructure.Services.People
{
    public class IdentificationRepository : BaseService, IIdentificationRepository
    {
        public IdentificationRepository(IDapper dapper, IOptions<ContexOptions> configuration) : base(dapper, configuration, InfoContexEnum.Odoo) { }

        public async Task<Identification?> GetIdentificationByIdentificationOnly(string documentNumberHash)
        {
            return await _dapper.GetAsync<Identification>("select * from public.getoperaciones()", documentNumberHash, CommandType.Text);
        }

        public async Task<List<Identification>?> GetIdentificationByPersonAndNumber(int personId)
        {
            return await _dapper.GetAllAsync<Identification>("select * from public.getoperaciones()", personId, CommandType.Text);
        }

    }
}
