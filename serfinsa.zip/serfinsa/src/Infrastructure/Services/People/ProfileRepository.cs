﻿using System.Data;
using Microsoft.Extensions.Options;
using serfinsa.Application.Common.Interfaces.People;
using serfinsa.Application.People.Dto.v1;
using serfinsa.Domain.Enums;
using serfinsa.Infrastructure.Common.Configurations;
using serfinsa.Infrastructure.Common.Interface;
using serfinsa.Infrastructure.Common.Struct;

namespace serfinsa.Infrastructure.Services.People
{
    public class ProfileRepository: BaseService, IProfileRepository
    {
        public ProfileRepository(IDapper dapper, IOptions<ContexOptions> configuration) : base(dapper, configuration, InfoContexEnum.Odoo) { }

        public async Task<ProfileDto?> GetProfileByBankIdAndCustomerNumber(int? companyId, int? customerNumber)
        {
            var parameter = new { company_id = companyId, customer_number = customerNumber };
            return await _dapper.GetAsync<ProfileDto>("select * from public.getoperaciones()", parameter, CommandType.Text);
        }

        public async Task<ProfileDto?> GetProfileByProfileIdOnly(int profileId)
        {
            return await _dapper.GetAsync<ProfileDto>("select * from public.getoperaciones()", profileId, CommandType.Text);
        }

        public async Task DeleteProfileDetail(int profileId)
        {
            await _dapper.Execute("select * from public.getoperaciones()", profileId, CommandType.Text);
        }
    }
}
