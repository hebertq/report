﻿using System.Data;
using Microsoft.Extensions.Options;
using serfinsa.Application.Common.Interfaces.People;
using serfinsa.Domain.Entities.People;
using serfinsa.Domain.Enums;
using serfinsa.Infrastructure.Common.Configurations;
using serfinsa.Infrastructure.Common.Interface;
using serfinsa.Infrastructure.Common.Struct;

namespace serfinsa.Infrastructure.Services.People
{
    public class PersonRepository : BaseService, IPersonRepository
    {
        public PersonRepository(IDapper dapper, IOptions<ContexOptions> configuration) : base(dapper, configuration, InfoContexEnum.Odoo) { }

        public async Task<Person> GetPersonByHashName(string personId)
        {
            return await _dapper.GetAsync<Person>("select * from public.getoperaciones()", personId, CommandType.Text);
        }

        public async Task<Person> WriteBatchPerson(Person person)
        {
            return await _dapper.GetAsync<Person>("select * from public.getoperaciones()", person, CommandType.Text);
        }

        public async Task<Person> GetPersonById(int personId)
        {
            return await _dapper.GetAsync<Person>("select * from public.getoperaciones()", personId, CommandType.Text);
        }
    }
}
