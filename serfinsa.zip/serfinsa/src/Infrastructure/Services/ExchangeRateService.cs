﻿using serfinsa.Infrastructure.SoapClient.Interfaces;
using serfinsa.Infrastructure.SoapClient.Model;
using serfinsa.Domain.SoapContract.ExchangeRate.v1.Response;
using serfinsa.Domain.Common.Generic;
using Microsoft.Extensions.Logging;
using serfinsa.Domain.Extensions;
using serfinsa.Application.Common.Interfaces;
using serfinsa.Domain.ApiContract.ExchangeRate.v1.Request;
using serfinsa.Domain.ApiContract.ExchangeRate.v1.Response;
using serfinsa.Application.Common.MappingExtensions;
using Microsoft.Extensions.Options;
using serfinsa.Infrastructure.Common.Configurations;
using serfinsa.Infrastructure.Policies;

namespace serfinsa.Infrastructure.Services
{
    public class ExchangeRateService : IExchangeRateService
    {
        private readonly ISoapClientService _soapClient;
        private readonly ILogger<ExchangeRateService> _logger;
        private readonly IOptions<RetryAndWaitPolicyOptions> _optionsRetry;
        private readonly string namespaces = "http://servicios.bcn.gob.ni";
        public ExchangeRateService(ISoapClientService soapClient,
                                   ILogger<ExchangeRateService> logger,
                                   IOptions<RetryAndWaitPolicyOptions> optionsRetry)
        {
            _soapClient = soapClient;
            _logger = logger;
            _optionsRetry = optionsRetry;
        }
        public async Task<Result<List<ExchangeRateResponse>>> GetExchangeRateOfMonth(ExchangeRateRequest requestSoap)
        {
            var xmlrequest = requestSoap.MapToRecuperaTCMes().ToXmlStringExtend("RecuperaTC_Mes", namespaces);
            var requestCourt = new RequestSoapMessage
            {
                Url = "https://servicios.bcn.gob.ni/Tc_Servicio/ServicioTC.asmx",
                Action = "?op=RecuperaTC_Mes",
                XmlModel = xmlrequest,
                NameSpaces = namespaces
            };
            var policy = RetryPolicy.GetRetryPolicyOnExchangeRate(_optionsRetry, _logger);
            var operation = async () => await _soapClient.PostAsyncRest<RecuperaTCMesResponse>(requestCourt);
            var responseSoap = await policy.ExecuteAsync(operation);


            if (responseSoap.Succeeded)
            {
                var response = responseSoap.Data!.MapToExchangeRateList();
                return new Result<List<ExchangeRateResponse>>(response, true, "", "");
            }
            else
            {
                var errormsj = $"{responseSoap.ErrorCode}: {responseSoap.ErrorMessage}";
                _logger.LogError(errormsj);
                return new Result<List<ExchangeRateResponse>>(null, false, responseSoap.ErrorCode, responseSoap.ErrorMessage);
            }
        }
    }
}
