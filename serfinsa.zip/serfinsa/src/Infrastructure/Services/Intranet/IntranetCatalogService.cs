﻿using System.Data;
using Microsoft.Extensions.Options;
using serfinsa.Application.Common.Interfaces.Intranet;
using serfinsa.Domain.Common.Generic;
using serfinsa.Domain.Enums;
using serfinsa.Infrastructure.Common.Configurations;
using serfinsa.Infrastructure.Common.Interface;
using serfinsa.Infrastructure.Common.Struct;

namespace serfinsa.Infrastructure.Services.Intranet
{
    public class IntranetCatalogService : BaseService, IIntranetCatalogService
    {
        public IntranetCatalogService(IDapper dapper, IOptions<ContexOptions> configuration) : base(dapper, configuration, InfoContexEnum.Odoo) { }

        /// <summary>
        /// Get global equivalences by catalog detail code
        /// </summary>
        /// <param name="catalogType">The catalog type</param>
        /// <param name="catalogDetailCode">Catalog detail code</param>
        /// <returns></returns>
        public async Task<List<CatalogDetaiLl>> GetLocalEquivalencesByDetailCodeAsync(CatalogTypeEnum catalogType)
        {
            return await _dapper.GetAllAsync<CatalogDetaiLl>("select * from public.getoperaciones()",catalogType, CommandType.Text);
        }

        /// <summary>
        /// Get local equivalence by BanK ID and CoreCode
        /// </summary>
        /// <param name="catalogType">The catalog type</param>
        /// <param name="coreCode">Core code</param>
        /// <returns></returns>
        public async Task<CatalogDetaiLl> GetGlobalEquivalenceByBankIdAndCoreCodeAsync(CatalogTypeEnum catalogType, string coreCode)
        {
            var parameter = new { catalog_type = catalogType, catalog_code = coreCode };
            return await _dapper.GetAsync<CatalogDetaiLl>("select * from public.getoperaciones()", parameter, CommandType.Text);
        }
    }
}
