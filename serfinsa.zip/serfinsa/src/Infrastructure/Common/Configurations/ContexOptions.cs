﻿namespace serfinsa.Infrastructure.Common.Configurations
{
    public class ContexOptions
    {
        public List<InfoContexDetail> Context { set; get; } = [];
    }
}
