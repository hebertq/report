﻿namespace serfinsa.Infrastructure.Common.Configurations
{
    public class RetryAndWaitPolicyOptions
    {
        public int RetryCount { get; set; }
        public double SecondsPerRetry { get; set; }
    }
}
