﻿using System.Data;
using Newtonsoft.Json;
using Npgsql;
using NpgsqlTypes;
using static Dapper.SqlMapper;

namespace serfinsa.Infrastructure.Common.Configurations
{
    public class JsonParameter<T> : ICustomQueryParameter
    {
        private readonly string _value;
        public JsonParameter(T value)
        {
            _value = JsonConvert.SerializeObject(value);
        }
        public void AddParameter(IDbCommand command, string name)
        {
            var parameter = new NpgsqlParameter(name, NpgsqlDbType.Jsonb);
            parameter.Value = _value;

            command.Parameters.Add(parameter);
        }
    }
}
