﻿using System.Data;
using serfinsa.Domain.Enums;
using serfinsa.Infrastructure.Common.Generic;

namespace serfinsa.Infrastructure.Common.Interface
{
    public interface IDapper
    {
        Task<T> GetAsync<T>(string sp, object parms, CommandType commandType = CommandType.Text) where T : class, new();
        Task<List<T>> GetAllAsync<T>(string? sp, object? parms, CommandType commandType = CommandType.StoredProcedure) where T : class, new();
        Task Execute(string sp, object parms, CommandType commandType = CommandType.StoredProcedure);
        Task<DataSet> QueryMultiple(string sp, object parms, CommandType commandType = CommandType.StoredProcedure);
        DatabaseProvider _context { set; get; }
        InfoContexEnum dbcontex { set; get; }
    }
}
