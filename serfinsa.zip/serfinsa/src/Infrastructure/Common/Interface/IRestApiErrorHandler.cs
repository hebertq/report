﻿using System.Text.Json;
using RestSharp;
using serfinsa.Domain.Common.Generic;

namespace serfinsa.Infrastructure.Common.Interface
{
    public interface IRestApiErrorHandler<TError> where TError : class
    {
        Result<T> ValidateResponseError<T>(RestResponse response, JsonSerializerOptions? jsonSerializerOptions = null) where T : class;
    }
}
