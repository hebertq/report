﻿using System.Data;
using Dapper;
using serfinsa.Domain.Enums;
using serfinsa.Domain.Exceptions;
using serfinsa.Infrastructure.Common.Generic;
using serfinsa.Infrastructure.Common.Interface;

namespace serfinsa.Infrastructure.Common.Struct
{
    public class Dapperr: IDapper 
    {
        public DatabaseProvider _context { set; get; }
        private bool _disposed = false;

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        public virtual void Dispose(bool disposing)
        {
            if (!_disposed && disposing)
            {
                _context?.Dispose();
            }

            _disposed = true;
        }     
        public InfoContexEnum dbcontex { set; get; }

        public async Task Execute(string sp, object parms, CommandType commandType = CommandType.StoredProcedure)
        {
            using (var connection = await _context.GetOpenConnection(dbcontex))
            {
                try
                {
                    await connection.ExecuteAsync(sp, parms, commandType: commandType).ConfigureAwait(false);
                }
                catch (Exception ex)
                {
                    throw new RulesException("Acceso", "No es posible ejecutar la intrucción a base de datos",ex);
                }
            }
        }
        public async Task<T> GetAsync<T>(string sp, object parms, CommandType commandType = CommandType.Text) where T : class, new()
        {
            using (var connection = await _context.GetOpenConnection(dbcontex))
            {
                try
                {
                    var result = await connection.QuerySingleOrDefaultAsync<T>(sp, parms, commandType: commandType).ConfigureAwait(false);
                    return result!;
                }
                catch (Exception ex)
                {
                    throw new RulesException("Acceso", "No es posible ejecutar la intrucción a base de datos", ex);
                }
            }
        }
        public async Task<List<T>> GetAllAsync<T>(string sp, object parms, CommandType commandType = CommandType.StoredProcedure) where T : class, new()
        {
            using (var connection = await _context.GetOpenConnection(dbcontex))
            {
                try
                {
                    var result = await connection.QueryAsync<T>(sp, parms, commandType: commandType).ConfigureAwait(false);
                    return result.ToList();
                }
                catch (Exception ex)
                {
                    throw new RulesException("Acceso", "No es posible ejecutar la intrucción a base de datos",ex);
                }
            }
        }
        public async Task<DataSet> QueryMultiple(string sp, object parms, CommandType commandType = CommandType.StoredProcedure)
        {
            using (var connection = await _context.GetOpenConnection(dbcontex))
            {
                try
                {
                    var result = await connection.ExecuteReaderAsync(sp, parms, commandType: commandType).ConfigureAwait(false);
                    return ConvertDataReaderToDataSet(result);
                }
                catch (Exception ex)
                {
                    throw new RulesException("Acceso", "No es posible ejecutar la intrucción a base de datos",ex);
                }
            }
        }
        private static DataSet ConvertDataReaderToDataSet(IDataReader data)
        {
            DataSet ds = new DataSet();
            int i = 0;
            while (!data.IsClosed)
            {
                ds.Tables.Add("Table" + (i + 1));
                ds.EnforceConstraints = false;
                ds.Tables[i].Load(data);
                i++;
            }
            return ds;
        }
    }
}
