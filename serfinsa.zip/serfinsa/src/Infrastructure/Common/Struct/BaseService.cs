﻿using Microsoft.Extensions.Options;
using serfinsa.Domain.Enums;
using serfinsa.Infrastructure.Common.Configurations;
using serfinsa.Infrastructure.Common.Interface;

namespace serfinsa.Infrastructure.Common.Struct
{
    public class BaseService
    {
        protected readonly IDapper _dapper;

        public BaseService(IDapper dapper, IOptions<ContexOptions> configuration, InfoContexEnum dbcontex)
        {
            _dapper = dapper;
            _dapper._context = new NpgContext(configuration);
            _dapper.dbcontex = dbcontex;
        }
    }
}
