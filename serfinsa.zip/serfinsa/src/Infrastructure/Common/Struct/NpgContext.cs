﻿using System.Data.Common;
using System.Data;
using serfinsa.Infrastructure.Common.Generic;
using serfinsa.Domain.Enums;
using Microsoft.Extensions.Options;
using Npgsql;
using serfinsa.Infrastructure.Common.Configurations;
using serfinsa.Domain.Exceptions;

namespace serfinsa.Infrastructure.Common.Struct
{
    public class NpgContext : DatabaseProvider
    {
        public NpgContext(IOptions<ContexOptions> configuration) : base(configuration)
        {
            AppContext.SetSwitch("Npgsql.EnableLegacyTimestampBehavior", true);
        }

        public override string GetConnectionString(InfoContexEnum name)
        {
            var contex = _config.Value.Context.FirstOrDefault(x => x.ContexName == name.ToString());
            string _connectionString;
            if (contex == null)
                throw new RulesException("configuración", "El contexto: " + name.ToString() + " mo esta configurado configurada en e json.");
            else
                _connectionString = string.Format("HOST = {0}; Database = {1};User ID={2}; Password={3}", contex.IpServer, contex.Database, contex.UserId, contex.PassId);

            return _connectionString;
        }

        public override DbProviderFactory Factory => NpgsqlFactory.Instance;
        public async Task<IDbConnection> CreateConnection(InfoContexEnum con)
        {
            return await GetOpenConnection(con);
        }
    }
}
