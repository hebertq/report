﻿using System.Data;
using System.Data.Common;
using Microsoft.Extensions.Options;
using serfinsa.Domain.Enums;
using serfinsa.Domain.Exceptions;
using serfinsa.Infrastructure.Common.Configurations;

namespace serfinsa.Infrastructure.Common.Generic
{
    public abstract class DatabaseProvider : IDisposable
    {
        private DbConnection? _connection;
        protected IOptions<ContexOptions> _config;
        public DatabaseProvider(IOptions<ContexOptions> configuration) => _config = configuration;
        public abstract DbProviderFactory Factory { get; }

        public virtual void Dispose()
        {
            _connection?.Dispose();
            _connection = null;
        }
        public abstract string GetConnectionString(InfoContexEnum name);

        public async Task<DbConnection> GetOpenConnection(InfoContexEnum _ContexName)
        {

             _connection = Factory.CreateConnection();
             _connection!.ConnectionString = GetConnectionString(_ContexName);

             await _connection.OpenAsync();
             if (_connection.State != ConnectionState.Open)
                 throw new CustomMessageException() { ExceptionMessage = "La coneccioón debe estar abierta!." };
  

            return _connection;
        }
    }
}
