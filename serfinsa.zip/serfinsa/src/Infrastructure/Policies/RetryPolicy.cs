﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Polly;
using Polly.Retry;
using serfinsa.Domain.Common.Generic;
using serfinsa.Domain.SoapContract.ExchangeRate.v1.Response;
using serfinsa.Infrastructure.Common.Configurations;
using serfinsa.Infrastructure.Services;

namespace serfinsa.Infrastructure.Policies
{
    public static class RetryPolicy
    {
        /// <summary>
        /// Retorna una politica de reintento y espera para el servicio de cambio del banco central
        /// </summary>
        /// <returns>Una politica de reintento y espera</returns>
        public static AsyncRetryPolicy<Result<RecuperaTCMesResponse>> GetRetryPolicyOnExchangeRate(IOptions<RetryAndWaitPolicyOptions> options, ILogger<ExchangeRateService> logger)
        {
            var retryPolicy = Policy
                .HandleResult<Result<RecuperaTCMesResponse>>(res => !res.Succeeded)
                .WaitAndRetryAsync(
                options.Value!.RetryCount,
                retryAttempt => TimeSpan.FromSeconds(options.Value!.SecondsPerRetry),
                (result, timeSpan, retryNumber, context) =>
                {
                    logger.LogError("Consult exchange rate of Nicaragua: Attempts: ({RetryNumber}/{RetryCount})", retryNumber, options.Value!.RetryCount);
                });

            return retryPolicy;
        }
    }
}
