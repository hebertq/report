﻿using serfinsa.Domain.Common.Generic;
using serfinsa.Infrastructure.SoapClient.Model;

namespace serfinsa.Infrastructure.SoapClient.Interfaces
{
    public interface ISoapClientService
    {
        Task<Result<T>> PostAsyncRest<T>(RequestSoapMessage soapMessage);
    }
}
