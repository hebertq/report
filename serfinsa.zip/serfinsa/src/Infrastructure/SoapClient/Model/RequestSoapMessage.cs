﻿namespace serfinsa.Infrastructure.SoapClient.Model
{
    public class RequestSoapMessage
    {
        public string Url { get; set; }
        public string Action { get; set; }
        public string XmlModel { get; set; }
        public string XmlHeader { get; set; }
        public string NameSpaces { get; set; }
    }
}
