﻿using serfinsa.Infrastructure.SoapClient.Interfaces;
using serfinsa.Infrastructure.SoapClient.Model;
using serfinsa.Domain.Extensions;
using serfinsa.Domain.Common.Generic;
using RestSharp;

namespace serfinsa.Infrastructure.SoapClient
{
    public class SoapClientService : ISoapClientService
    {
        public SoapClientService(){}
        public async Task<Result<T>> PostAsyncRest<T>(RequestSoapMessage soapMessage)
        {
            var client = new RestClient(soapMessage.Url!);
            var request = new RestRequest($"{soapMessage.Url!}{soapMessage.Action}", Method.Post);
            request.AddHeader("Content-Type", "text/xml");           
            request.AddStringBody(soapMessage.XmlModel, DataFormat.Xml);
            var response = await client.ExecuteAsync(request);
            return new Result<T>(XmlExtensions.DeserializeInnerSoapObject<T>(response.Content!, soapMessage.NameSpaces), true, "", "");
        }
    }
}
