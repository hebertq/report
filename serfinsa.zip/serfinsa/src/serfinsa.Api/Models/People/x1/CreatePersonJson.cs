﻿using serfinsa.Application.People.Models.v1;
using serfinsa.Domain.Entities.People;
using System.ComponentModel.DataAnnotations;

namespace serfinsa.Api.Models.People.x1
{
    /// <summary>
    /// To create a person
    /// </summary>
    public class CreatePersonJson : CreatePersonModel
    {
        /// <summary>
        /// Identification information object
        /// </summary>
        [Required]
        public Identification? IdentificationInformation { get; set; } = null;

        /// <summary>
        /// Principal Officer
        /// </summary>
        public string? OfficialCode { get; set; }

        /// <summary>
        /// Secondary Officer
        /// </summary>
        public string? SubOfficialCode { get; set; }

        /// <summary>
        /// Last user
        /// </summary>
        public string? LastUser { get; set; }
    }
}
