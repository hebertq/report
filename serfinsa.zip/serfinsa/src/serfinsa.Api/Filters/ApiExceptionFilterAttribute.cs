﻿using System.Net;
using LAFISE.CrossCutting.Core.Exceptions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using serfinsa.Domain.Common.Generic;
using serfinsa.Domain.Exceptions;

namespace serfinsa.Api.Filters
{
    /// <summary>
    /// Class to define how the different exceptions are going to be handled and returned to the API client
    /// </summary>
    public class ApiExceptionFilterAttribute : ExceptionFilterAttribute
    {
        private readonly IDictionary<Type, Action<ExceptionContext>> _exceptionHandlers;

        /// <summary>
        /// Used to handle the different exceptions
        /// </summary>
        public ApiExceptionFilterAttribute()
        {
            // Register known exception types and handlers.
            _exceptionHandlers = new Dictionary<Type, Action<ExceptionContext>>
            {
                { typeof(FluentValidation.ValidationException), HandleValidationException },
                { typeof(NotFoundException), HandleNotFoundException },
                { typeof(BadRequestException), HandleBadRequestException },
                { typeof(UnauthorizedAccessException), HandleUnauthorizedAccessException },
                { typeof(ForbiddenAccessException), HandleForbiddenAccessException },
            };
        }

        /// <summary>
        /// Method call when an exception is raised
        /// </summary>
        /// <param name="context"></param>
        public override void OnException(ExceptionContext context)
        {
            HandleException(context);

            base.OnException(context);
        }

        private void HandleException(ExceptionContext context)
        {
            Type type = context.Exception.GetType();
            if (_exceptionHandlers.TryGetValue(type, out var handler))
            {
                handler.Invoke(context);
                return;
            }

            if (!context.ModelState.IsValid)
            {
                HandleInvalidModelStateException(context);
                return;
            }

            HandleUnknownException(context);
        }

        private void HandleUnknownException(ExceptionContext context)
        {
            var error = SetError(context.Exception);                   
            var details = new ProblemDetails
            {
                Status = StatusCodes.Status500InternalServerError,
                Title = "An error occurred while processing your request.",
                Detail = error
            };

            context.Result = new ObjectResult(details)
            {
                StatusCode = StatusCodes.Status500InternalServerError
            };

            context.ExceptionHandled = true;
        }

        private void HandleValidationException(ExceptionContext context)
        {
            var exception = (FluentValidation.ValidationException)context.Exception;

            var errors = exception.Errors.GroupBy(e => e.PropertyName, e => e.ErrorMessage)
                .ToDictionary(failureGroup => failureGroup.Key, failureGroup => failureGroup.ToArray());

            var details = new ValidationProblemDetails(errors)
            {
                Type = "https://tools.ietf.org/html/rfc7231#section-6.5.1"
            };

            context.Result = new BadRequestObjectResult(details);

            context.ExceptionHandled = true;
        }

        private void HandleInvalidModelStateException(ExceptionContext context)
        {
            var details = new ValidationProblemDetails(context.ModelState)
            {
                Type = "https://tools.ietf.org/html/rfc7231#section-6.5.1"
            };

            context.Result = new BadRequestObjectResult(details);

            context.ExceptionHandled = true;
        }

        private void HandleNotFoundException(ExceptionContext context)
        {
            var exception = (NotFoundException)context.Exception;

            var details = new ProblemDetails()
            {
                Type = "https://tools.ietf.org/html/rfc7231#section-6.5.4",
                Title = "The specified resource was not found.",
                Detail = exception.Message
            };

            context.Result = new NotFoundObjectResult(details);

            context.ExceptionHandled = true;
        }

        private void HandleUnauthorizedAccessException(ExceptionContext context)
        {
            var details = new ProblemDetails
            {
                Status = StatusCodes.Status401Unauthorized,
                Title = "Unauthorized",
                Type = "https://tools.ietf.org/html/rfc7235#section-3.1"
            };

            context.Result = new ObjectResult(details)
            {
                StatusCode = StatusCodes.Status401Unauthorized
            };

            context.ExceptionHandled = true;
        }

        private void HandleForbiddenAccessException(ExceptionContext context)
        {
            var details = new ProblemDetails
            {
                Status = StatusCodes.Status403Forbidden,
                Title = "Forbidden",
                Type = "https://tools.ietf.org/html/rfc7231#section-6.5.3"
            };

            context.Result = new ObjectResult(details)
            {
                StatusCode = StatusCodes.Status403Forbidden
            };

            context.ExceptionHandled = true;
        }

        private void HandleBadRequestException(ExceptionContext context)
        {
            if (context.Exception is BadRequestException exception)
            {
                var details = new ProblemDetails
                {
                    Status = StatusCodes.Status400BadRequest,
                    Title = "One or more errors have occurred.",
                    Detail = exception.Error
                };

                context.Result = new BadRequestObjectResult(details);

                context.ExceptionHandled = true;
            }
        }

        private string SetError(Exception error)
        {
            var modelState = new ModelStateDictionary();
            string MsjError = string.Format("Estimado usuario, ha ocurrido un error interno,{0}:",
                                       Environment.NewLine + "por favor contacte con el administrador del sistema" + System.Environment.NewLine);
            var _jsonSettings = new JsonSerializerSettings()
            {
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore,
                Formatting = Formatting.Indented,
                ContractResolver = new CamelCasePropertyNamesContractResolver(),
                NullValueHandling = NullValueHandling.Ignore
            };

            switch (error)
            {
                case RulesException ex:
                    
                    ex.AddModelStateErrors(modelState);
                    var json = JsonConvert.SerializeObject(modelState.Errors(true), _jsonSettings);
                    var daer = JsonConvert.DeserializeObject<List<ErrorInfoLog>>(json.ToString(), _jsonSettings);
                    MsjError += string.Format("Status: {0}{1}", HttpStatusCode.BadRequest.ToString() + System.Environment.NewLine, "Tipo de excepción: " + System.Environment.NewLine);
                    foreach (var item in daer)
                    {
                        if (item.Key == "request")
                        {
                            MsjError += string.Format("{0}: {1}", item.Key, "Error al serializar los datos enviados." + System.Environment.NewLine);
                        }
                        else
                        {
                            string valor = item.Value.ToString().Replace("[", "").Replace("]", "").Replace("\x022", "").Replace("\r\n", "").Trim();
                            MsjError += string.Format("{0}: {1}", item.Key, valor + System.Environment.NewLine);
                        }
                    }
                    break;
                case CustomMessageException ex:
                    MsjError += string.Format("Status: {0}{1}{2}", HttpStatusCode.InternalServerError.ToString() + System.Environment.NewLine,
                                "Tipo de excepción: " + System.Environment.NewLine,
                                "Error: " + ex.ExceptionMessage + System.Environment.NewLine);

                    break;
                case UnauthorizedAccessException ex:
                    MsjError += string.Format("Status: {0}{1}{2}", HttpStatusCode.InternalServerError.ToString() + System.Environment.NewLine,
                                "Tipo de excepción: " + System.Environment.NewLine,
                                "Error: " + ex.Message + System.Environment.NewLine);
                    break;
                case NotFoundException ex:
                    MsjError += string.Format("Status: {0}{1}{2}", HttpStatusCode.InternalServerError.ToString() + System.Environment.NewLine,
                                "Tipo de excepción: " + System.Environment.NewLine,
                                "Error: " + ex.Message + System.Environment.NewLine);
                    break;
                default:
                    MsjError += string.Format("Status: {0}{1}{2}", HttpStatusCode.InternalServerError.ToString() + System.Environment.NewLine,
                                "Tipo de excepción: " + System.Environment.NewLine,
                                "Error: " + error.Message + System.Environment.NewLine);
                    break;
            }

            return MsjError;
        }
    }
}
