﻿using System.ComponentModel.DataAnnotations;
using AutoMapper;
using LAFISE.CrossCutting.Core.Enums;
using Microsoft.AspNetCore.Mvc;
using serfinsa.Api.Filters;
using serfinsa.Api.Models.People.x1;
using serfinsa.Application.People.Commands.v1;
using serfinsa.Application.People.Dto.v1;
using Swashbuckle.AspNetCore.Annotations;

namespace serfinsa.Api.Controllers.v1
{ /// <summary>
  /// Controller that manage all the To Do requests
  /// </summary>
    [ApiController]
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}")]
    public class PeopleController : ApiControllerBase
    {
        private readonly IMapper _mapper;

        /// <summary>
        /// Constructor used to inject different services
        /// </summary>
        /// <param name="mapper"></param>
        public PeopleController(IMapper mapper)
        {
            _mapper = mapper;
        }

        /// <summary>
        /// Creates a new person
        /// </summary>
        /// <remarks>
        /// Creates a new person
        /// </remarks>
        /// <param name="BANK_ID">The requesting bank id</param>
        /// <param name="BODY">The data contract structure from the person</param>
        [MapToApiVersion("1.0")]
        [HttpPost("banks/{BANK_ID}/people")]
        [ProducesResponseType(typeof(PersonDto), StatusCodes.Status201Created)]
        [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status500InternalServerError)]
        [SwaggerOperation(Tags = new[] { "People API" })]
        [ValidateModelState]
        //[ServiceFilter(typeof(KycAuthorizationFilter))]
        //[PermisssionKyc(nameof(Permissions.PersonCreate))]
        public virtual async Task<IActionResult> CreatePersonAsync([FromRoute][Required] CountryEnum BANK_ID,
            [FromBody][Required] CreatePersonJson BODY)
        {
            Request.Headers.TryGetValue("x-biometric-certificate", out var biometricToken);
            //Request.Headers.TryGetValue("x-channel-id", out var channelId);
            //Request.Headers.TryGetValue("x-consumer-id", out var consumerId);
            //Request.Headers.TryGetValue("x-migration-people", out var isMigrationFlag);

            //var clientId = consumerId.FirstOrDefault() ?? ControllerContext!.HttpContext!.Items["AppClientId"]!.ToString();

            //bool isUnitTesting = bool.Parse(Environment.GetEnvironmentVariable("IS_UNIT_TESTING")! ?? "False");

            //if (isUnitTesting)
            //    _kycPermissionValidate.ProfileLogId = ControllerContext.HttpContext.Request.Headers["x-profilelog-id"]!;

            var response = await Mediator.Send(
              _mapper.Map<CreatePersonCommand>(BODY, opt => opt.AfterMap(
                  (_, dest) =>
                  {
                      //dest.BiometricToken = biometricToken.FirstOrDefault() ?? string.Empty;
                      //dest.ChannelId = channelId.FirstOrDefault() ?? string.Empty;
                      //dest.SourceSystem = clientId ?? string.Empty;
                      //dest.BankId = BANK_ID;
                      //dest.ProfileLogId = _kycPermissionValidate.ProfileLogId;
                  })));

            return response != null ? Created(string.Empty, response) : BadRequest();
        }
    }
}
