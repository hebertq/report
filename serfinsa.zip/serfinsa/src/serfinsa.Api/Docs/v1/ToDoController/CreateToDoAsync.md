- **Summary**: Pequena descripcion de la funcionalidad.
- **Description**: 

# Como trabajar documentacion de endpoints

Para documentar endpoints utilizando [markdown](https://www.markdownguide.org/basic-syntax/) se debe de seguir la siguiente estructura a nivel de proyectos:

> Mi Proyecto (csproj)
>  
>> Controllers
>>> v1 (version del controlador)
>>>> Mi controlador
>
>> Docs
>>> v1 (version del controlador a documentar)
>>>> Nombre del controlador
>>>>> Archivo Markdown con nombre del endpoint a documentar

Por ejemplo:

Si tengo en la carpeta `v1` un controlador llamado `ToDoController` en el cual tengo un endpoint (metodo) llamado `CreateToDoAsync`, para documentar este endpoint, deberia de tener a nivel de carpeta `Docs` una estructura de la siguiente manera:

> Docs
>> v1
>>> ToDoController
>>>> CreateToDoAsync.md

## Consideraciones importantes

- Todos los archivos maskdown de documentacion, a nivel de sus propiedades deben estar como copy always. Si esto no es realizado, al momento de levantar el API los archivos no seran encontrados en el compilado.

- Todo aquel metodo (endpoint) que no tenga un archivo markdown para el controlador especifico, en la version del controlador correspondiente, tomara por defecto la documentacion realizada a nivel de endpoint.

- Para que todo desarrollo se considere **TERMINADO** debera de contener su documentacion detallada de la funcionalidad con su archivo markdown correspondiente.
