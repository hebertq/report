﻿using serfinsa.Api.Models.v1;
using RestSharp;

namespace serfinsa.Api.IntegrationTests.Todo.Commands
{
    using static Testing;

    public class CreateTodoTest
    {
        [Test]
        public async Task ShouldCreateTodo()
        {
            var body = new CreateTodoJson() { Description = "This is the todo test", Name = "TodoTest", Version = 1 };

            var response = await TestRestClient.PostRequest(new RestRequest("todos".ToRequestUrl()).AddJsonBody(body));

            Assert.Multiple(() =>
            {
                Assert.That(response.Succeeded, Is.True);
            });
        }

        [Test]
        public async Task ShouldRequireNotEmptyDescription()
        {
            var body = new CreateTodoJson() { Description = "", Name = "TodoTest", Version = 1 };

            var response = await TestRestClient.PostRequest(new RestRequest("todos").AddJsonBody(body));

            Assert.Multiple(() =>
            {
                Assert.That(response.Succeeded, Is.False);
            });
        }
    }
}
