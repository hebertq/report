﻿using FluentAssertions;
using serfinsa.Api.Models.v1;
using serfinsa.Application.Todo.Dto.v1;
using RestSharp;

namespace serfinsa.Api.IntegrationTests.Todo.Commands
{
    using static Testing;

    public class UpdateTodoTodoTest
    {
        [Test]
        public async Task ShouldUpdateTodo()
        {
            // Arrange (prepara escenario)
            var body = new UpdateTodoJson()
            {
                Description = "This is the todo test updated",
                Name = "TodoUpdt",
                Version = 2,
            };

            var request = new RestRequest("todos/1".ToRequestUrl()).AddJsonBody(body);

            // Act (efectua accion a probar)
            var response = await TestRestClient.PutRequest<TodoDto>(request);

            // Assert (verifica resultado)
            Assert.Multiple(() =>
            {
                Assert.That(response.Succeeded, Is.True);
                Assert.That(response.Data, Is.Not.Null);

                var data = response.Data!;

                data.Id.Should().Be(1);
                data.Name.Should().Be("TodoUpdt");
                data.Description.Should().Be("This is the todo test updated");
                data.Version.Should().Be(2);
            });
        }

        [Test]
        public async Task ShouldRequireTodoId()
        {
            // Arrange (prepara escenario)
            var body = new UpdateTodoJson()
            {
                Description = "This is the todo test updated",
                Name = "TodoUpdt",
                Version = 2,
            };

            var request = new RestRequest("todos/0".ToRequestUrl()).AddJsonBody(body);

            // Act (efectua accion a probar)
            var response = await TestRestClient.PutRequest<TodoDto>(request);

            // Assert (verifica resultado)
            Assert.Multiple(() =>
            {
                Assert.That(response.Succeeded, Is.False);
                Assert.That(response.ErrorCode, Is.EqualTo("BadRequest"));
            });
        }
    }
}
