﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Moq;

namespace serfinsa.Api.IntegrationTests
{
    public class CustomWebApplicationFactory : WebApplicationFactory<Program>
    {
        public IServiceScopeFactory ScopeFactory = null!;
        private IConfigurationRoot _configuration = null!;

        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {
            builder.ConfigureServices((_, services) =>
            {
                ConfigureDependencies(services).Wait();
            });
        }

        // Change this method to ASYNC if needed
        private Task ConfigureDependencies(IServiceCollection services)
        {
            // Use this variable to conditionally inject services when not in unit testing mode (like AWS Services)
            Environment.SetEnvironmentVariable("IS_UNIT_TESTING", "True");

            // TODO: add your testcontainers and fixtures here

            // Dependency injection and configuration
            var configurationBuilder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", true, true)
                .AddEnvironmentVariables();

            _configuration = configurationBuilder.Build();
            services.AddSingleton(Mock.Of<IWebHostEnvironment>(
                webHostEnv =>
                    webHostEnv.EnvironmentName == "Development" &&
                    webHostEnv.ApplicationName == "serfinsa"));
            services.AddApplicationServices();
            services.AddInfrastructureServices(_configuration);
            services.AddSingleton<IConfiguration>(_configuration);
            services.AddLogging();
            ScopeFactory = services.BuildServiceProvider().GetService<IServiceScopeFactory>()!;

            return Task.CompletedTask;
        }
    }
}
